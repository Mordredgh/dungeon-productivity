﻿/* UI */
function generateSubtasks(formPrefix = 'editQ') {
  const isNew = formPrefix === 'q';
  const prefixInput = document.getElementById(isNew ? 'qSubtaskPrefix' : 'subtaskPrefix');
  const countInput = document.getElementById(isNew ? 'qSubtaskCount' : 'subtaskCount');
  const prefix = (prefixInput?.value.trim()) || 'Ítem';
  const count  = Math.min(100, Math.max(1, parseInt(countInput?.value) || 0));
  if (!count) { toast('⚠️', 'Escribe un número de subtareas'); return; }
  const notesEl = document.getElementById(isNew ? 'qNotes' : 'editQNotes');
  const existing = notesEl.value.trimEnd();
  const items = Array.from({ length: count }, (_, i) => `- [ ] ${prefix} ${i + 1}`).join('\n');
  notesEl.value = existing ? existing + '\n' + items : items;
}

function openEditQuest(id) {
  const q = quests.find(x => x.id === id);
  if (!q) return;
  document.getElementById('editQuestId').value     = id;
  document.getElementById('editQName').value       = q.name;
  document.getElementById('editQType').value       = q.type;
  const validRarities = ['mitico','legendario','epico','normal','comun'];
  document.getElementById('editQPriority').value   = validRarities.includes(q.priority) ? q.priority : 'normal';
  document.getElementById('editQDeadline').value   = q.deadline || '';
  document.getElementById('editQNotes').value      = q.notes || '';
  document.getElementById('editQTags').value       = q.tags || '';
  // Show reminder time field for habits
  const habitReminderGroup = document.getElementById('habitReminderGroup');
  const reminderInp = document.getElementById('editQReminderTime');
  if (habitReminderGroup) habitReminderGroup.style.display = q.type === 'habit' ? '' : 'none';
  if (reminderInp) {
    const m = (q.tags || '').match(/reminder-(\d{1,2}:\d{2})/i);
    reminderInp.value = m ? m[1].padStart(5, '0') : '';
  }
  document.getElementById('editQEstTime').value    = q.est_time || '';
  document.getElementById('editQRepeat').value     = q.repeat_days || '';
  document.getElementById('editQStartDate').value  = q.quest_start_date || '';
  document.getElementById('editQDependsOn').value  = q.depends_on || '';
  if (typeof populateGoalSelect === 'function') populateGoalSelect(q.goal_id || '');
  const zoneEl = document.getElementById('editQZone');
  if (zoneEl) {
    const tagStr = q.tags || '';
    if (/\bestudio\b/i.test(tagStr)) zoneEl.value = 'estudio';
    else if (/\bejercicio\b/i.test(tagStr)) zoneEl.value = 'ejercicio';
    else zoneEl.value = '';
  }
  openModal('editQuestModal');
}

async function doImportCSV() {
  const text = document.getElementById('importCsvText').value.trim();
  if (!text || !hero) return;
  const validTypes = ['main','side','daily','weekly'];
  const validPrio  = ['mitico','legendario','epico','normal','comun'];
  let count = 0;
  for (const line of text.split('\n').map(l=>l.trim()).filter(Boolean)) {
    const [name, tipo, prioridad, deadline] = line.split(',').map(s => s.trim());
    if (!name) continue;
    await addQuest({
      name,
      type:     validTypes.includes(tipo) ? tipo : 'side',
      priority: validPrio.includes(prioridad) ? prioridad : 'normal',
      deadline: deadline || null,
      hero_id:  hero.id
    });
    count++;
  }
  closeModal('importModal');
  document.getElementById('importCsvText').value = '';
  toast('📊', `${count} misiones importadas desde CSV.`);
}

function setActiveQuest(id) {
  const q = quests.find(x => x.id === id);
  if (!q) return;
  // Con el pomodoro ya corriendo el vínculo queda fijo hasta que termine o
  // se reinicie — si no, se podría "robar" el bono de verificación de una
  // tarea a otra al último segundo sin haberle dedicado tiempo real.
  if (timer.running) {
    toast('🔒', 'El Pomodoro ya está en marcha — no se puede cambiar la misión vinculada hasta que termine o lo reinicies.');
    return;
  }
  timer.activeQuest = id;
  document.getElementById('pomTaskLabel').textContent = `⚔️ ${q.name}`;
  if (typeof saveTimerState === 'function') saveTimerState();
  toast('🍅', `Pomodoro vinculado: ${q.name}`);
}

function openModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el._returnFocus = document.activeElement;
  el.setAttribute('aria-hidden', 'false');
  el.setAttribute('role', 'dialog');
  el.setAttribute('aria-modal', 'true');
  if (id === 'quickAddModal') {
    if (typeof populateGoalSelect === 'function') populateGoalSelect('', 'qGoal');
    if (typeof syncQuestHabitFields === 'function') syncQuestHabitFields('q');
  }
  el.classList.add('open');
  if (id === 'levelupModal') return; // animLevelUpModal se llama al final de showLevelUp
  if (typeof animModalOpen === 'function') animModalOpen(id);
  requestAnimationFrame(() => el.querySelector('button, input, select, textarea, [tabindex]:not([tabindex="-1"])')?.focus());
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (!el || !el.classList.contains('open')) return;
  // Kill any GSAP tweens and clear inline styles so CSS transition takes over
  if (typeof gsap !== 'undefined') {
    gsap.killTweensOf(el);
    gsap.set(el, { clearProps: 'opacity,pointerEvents' });
    const box = el.querySelector('.modal-box,.modal-content,.edit-modal,.quick-create-box,.shortcuts-box,.modal');
    if (box) { gsap.killTweensOf(box); gsap.set(box, { clearProps: 'opacity,transform' }); }
  }
  el.classList.remove('open'); // CSS transition: opacity .25s handles the visual fade
  el.setAttribute('aria-hidden', 'true');
  el._returnFocus?.focus?.();
}

function initModalAccessibility() {
  document.querySelectorAll('.modal-overlay').forEach(el => {
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-modal', 'true');
    el.setAttribute('aria-hidden', el.classList.contains('open') ? 'false' : 'true');
  });
}

function showLevelUp(lvl) {
  const dynTitle = typeof getDynamicTitle === 'function' && hero ? getDynamicTitle(hero) : TITLES[Math.min(lvl - 1, TITLES.length - 1)];
  document.getElementById('luLevel').textContent = `Nivel ${lvl}`;
  document.getElementById('luTitle').textContent = dynTitle;
  document.getElementById('luDesc').textContent  = `¡Has ascendido a ${dynTitle}!`;

  // Perks list
  const perksEl = document.getElementById('luPerks');
  if (perksEl) {
    const perks = ['✨ +1 punto de atributo disponible'];
    if (lvl % 10 === 0) perks.push(`🏆 ¡Hito alcanzado! Nivel ${lvl}`);
    if (lvl === 50)     perks.push('⭐ ¡Nivel máximo! Ya puedes Ascender en tu hoja de personaje.');
    if ((hero?.prestige || 0) > 0) perks.push(`⭐×${hero.prestige} Bonus de Ascensión activo: +${hero.prestige * 5}% XP`);
    perksEl.innerHTML = perks.map((p, i) =>
      `<div class="levelup-perk" style="animation-delay:${i * 0.12}s">${escHtml(p)}</div>`
    ).join('');
  }

  // Floating stars
  const starsEl = document.getElementById('luStars');
  if (starsEl) {
    starsEl.innerHTML = '';
    const icons = ['⭐','✨','💫','🌟'];
    for (let i = 0; i < 14; i++) {
      const s = document.createElement('div');
      s.className = 'levelup-star';
      s.textContent = icons[i % 4];
      s.style.cssText = `left:${(Math.random()*86+5).toFixed(1)}%;top:${(Math.random()*70+15).toFixed(1)}%;animation-delay:${(Math.random()*0.9).toFixed(2)}s;animation-duration:${(1.2+Math.random()*0.8).toFixed(2)}s`;
      starsEl.appendChild(s);
    }
  }

  openModal('levelupModal');
  if (typeof animLevelUpModal === 'function') animLevelUpModal();
  playLevelUpSound();
  spawnLevelUpParticles();
  spawnConfetti();
  setTimeout(() => {
    const m = document.getElementById('levelupModal');
    if (m && m.classList.contains('open')) closeModal('levelupModal');
  }, 6000);
}

function toast(icon, msg, duration) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const div = document.createElement('div');
  div.className = 'toast';
  div.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${escHtml(msg)}</span>`;
  container.appendChild(div);
  if (typeof animToastIn === 'function') animToastIn(div);
  const ms = duration || 4000;
  setTimeout(() => {
    if (typeof animToastOut === 'function') animToastOut(div, () => div.remove());
    else div.remove();
  }, ms - 280);
}

function toastAction(icon, msg, btnText, fn, duration) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const div = document.createElement('div');
  div.className = 'toast toast-action';
  div.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${escHtml(msg)}</span><button class="toast-btn">${escHtml(btnText)}</button>`;
  div.querySelector('.toast-btn').addEventListener('click', () => { fn(); div.remove(); });
  container.appendChild(div);
  if (typeof animToastIn === 'function') animToastIn(div);
  const _ms = duration || 9000;
  setTimeout(() => {
    if (typeof animToastOut === 'function') animToastOut(div, () => div.remove());
    else div.remove();
  }, _ms - 280);
}

function spawnParticle(text, sourceEl) {
  playXpSound();
  const rect = sourceEl ? sourceEl.getBoundingClientRect() : { left: window.innerWidth / 2, top: window.innerHeight / 2 };
  const el = document.createElement('div');
  el.className = 'particle';
  el.textContent = text;
  el.style.left = (rect.left + 10) + 'px';
  el.style.top = rect.top + 'px';
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 900);
}

function spawnHPParticle(amount, el) {
  const heal = amount > 0;
  const div  = document.createElement('div');
  div.className = `particle particle-hp ${heal ? 'particle-heal' : 'particle-dmg'}`;
  div.textContent = (heal ? '+' : '') + amount + ' HP';
  const rect = el ? el.getBoundingClientRect() : { left: window.innerWidth/2, top: window.innerHeight/2 };
  div.style.left = (rect.left + 10) + 'px';
  div.style.top  = rect.top + 'px';
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 950);
}

function spawnGoldParticle(amount, el) {
  const div = document.createElement('div');
  div.className = 'particle particle-gold';
  div.textContent = '+' + amount + ' 🪙';
  const rect = el ? el.getBoundingClientRect() : { left: window.innerWidth/2, top: window.innerHeight/2 };
  div.style.left = (rect.left + 10) + 'px';
  div.style.top  = rect.top + 'px';
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 950);
}

function spawnLevelUpParticles() {
  const emojis = ['⭐','✨','🌟','💫','🎉','🏆'];
  for (let i = 0; i < 12; i++) {
    setTimeout(() => {
      const el = document.createElement('div');
      el.className = 'particle';
      el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      el.style.left = Math.random() * window.innerWidth + 'px';
      el.style.top = Math.random() * window.innerHeight * 0.7 + 'px';
      el.style.fontSize = '24px';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 900);
    }, i * 80);
  }
}


function escHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

/* EXPORT / IMPORT */
function exportData() {
  const data = { hero, quests, exported_at: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `dungeon-backup-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  toast('📤', 'Datos exportados.');
}

async function doImport() {
  const text = document.getElementById('importText').value.trim();
  const type = document.getElementById('importType').value;
  if (!text || !hero) return;
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  for (const name of lines) await addQuest({ name, type, priority: 'normal', hero_id: hero.id });
  closeModal('importModal');
  document.getElementById('importText').value = '';
  toast('📥', `${lines.length} misiones importadas.`);
}

/* VIEW NAV */
const CHAR_HUB_TABS = { 'skill-tree':'skills', 'runes':'runes', 'bestiary':'bestiary', 'smithy':'smithy' };

const _VIEW_BG = {
  quests:'fondo_misiones', goals:'fondo_metas', stats:'fondo_stats',
  achievements:'fondo_logros', history:'fondo_history', shop:'fondo_shop',
  inventory:'fondo_inventario', pets:'fondo_pets',
  'dungeon-grows':'fondo_dungeon-grows', integrations:'fondo_integrations',
};
const _CTAB_BG = {
  sheet:'fondo_character', skills:'fondo_habilidades', runes:'fondo_runas',
  bestiary:'fondo_bestiario', smithy:'fondo_herrero', 'sala-personal':'fondo_character',
};
function _setPageBg(name) {
  const el = document.getElementById('dungeon-bg');
  if (!el) return;
  el.style.backgroundImage = name ? `url(images/${name}.webp)` : 'none';
}

function switchView(v) {
  if (CHAR_HUB_TABS[v]) { switchCharTab(CHAR_HUB_TABS[v]); v = 'character'; }

  const _currentEl = document.querySelector('.view.active');
  const _newId     = `view-${v}`;

  const _doSwitch = () => {
    document.querySelectorAll('.view-tab, .sidebar-item').forEach(t => t.classList.toggle('active', t.dataset.view === v));
    document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === _newId));
    if (v === 'character') {
      const activeCtab = document.querySelector('.char-tab-panel.active');
      const ctabId = activeCtab?.id?.replace('ctab-', '') || 'sheet';
      _setPageBg(_CTAB_BG[ctabId] || null);
    } else {
      _setPageBg(_VIEW_BG[v] || null);
    }
    const charHub = document.getElementById('charHubTabs');
    if (charHub) charHub.style.display = v === 'character' ? 'flex' : 'none';
    if (v === 'stats')        renderStats();
    if (v === 'achievements') renderAchievements();
    if (v === 'history')      { historyPage = 1; renderHistory(); }
    if (v !== 'pets' && typeof cleanupGarden === 'function') cleanupGarden();
    if (v === 'pets')         { renderPets(); if (typeof renderActivePet === 'function') renderActivePet(); switchPetsTab('list'); }
    if (v === 'shop')         renderShopView();
    if (v === 'inventory')    { if (typeof renderInventory==='function')    renderInventory(); }
    if (v === 'character')    { if (typeof renderCharacterSheet==='function') renderCharacterSheet(); }
    if (v === 'goals')        { if (typeof renderGoals==='function')         renderGoals(); }
    if (v === 'dungeon-grows'){ if (typeof renderDungeonGrows==='function')  renderDungeonGrows(); }
    if (v === 'zones')        { if (typeof renderZones==='function')         renderZones(); }
    if (v === 'worldmap')     { if (typeof renderWorldMap==='function')      renderWorldMap(); }
    if (v === 'factions')     { if (typeof renderFactions==='function')      renderFactions(); }
    if (v === 'integrations') { renderIntegrations(); }
    if (v === 'config')       { if (typeof renderConfigView === 'function') renderConfigView(); }
    const moreBtn = document.getElementById('mobileNavMoreBtn');
    if (moreBtn) {
      const primaryViews = ['quests', 'character', 'stats'];
      moreBtn.classList.toggle('mobile-nav-more-active', !primaryViews.includes(v));
    }
    const newEl = document.getElementById(_newId);
    if (newEl && typeof animViewIn === 'function') animViewIn(newEl, v);
  };

  if (_currentEl && _currentEl.id !== _newId && typeof animViewOut === 'function') {
    animViewOut(_currentEl, _doSwitch);
  } else {
    _doSwitch();
  }
}

function openMobileMore() {
  document.getElementById('mobileNavMoreOverlay')?.classList.add('open');
  document.getElementById('mobileNavMoreSheet')?.classList.add('open');
  if (typeof animMobileSheetOpen === 'function') animMobileSheetOpen();
}
function closeMobileMore() {
  if (typeof animMobileSheetClose === 'function') {
    animMobileSheetClose(() => {
      document.getElementById('mobileNavMoreOverlay')?.classList.remove('open');
      document.getElementById('mobileNavMoreSheet')?.classList.remove('open');
    });
  } else {
    document.getElementById('mobileNavMoreOverlay')?.classList.remove('open');
    document.getElementById('mobileNavMoreSheet')?.classList.remove('open');
  }
}

function switchCharTab(tab) {
  // If character view isn't active yet, activate it first
  if (!document.getElementById('view-character')?.classList.contains('active')) {
    document.querySelectorAll('.view-tab, .sidebar-item').forEach(t => t.classList.toggle('active', t.dataset.view === 'character'));
    document.querySelectorAll('.view').forEach(el => el.classList.toggle('active', el.id === 'view-character'));
  }
  document.querySelectorAll('.char-tab').forEach(t => t.classList.toggle('active', t.dataset.ctab === tab));
  document.querySelectorAll('.char-tab-panel').forEach(p => p.classList.toggle('active', p.id === `ctab-${tab}`));
  // Render the appropriate content
  if (tab === 'sheet')    { if (typeof renderCharacterSheet==='function') renderCharacterSheet(); }
  if (tab === 'skills')   { if (typeof renderSkillTree==='function')      renderSkillTree(); }
  if (tab === 'runes')    { if (typeof renderRunePanel==='function')      renderRunePanel(); }
  if (tab === 'bestiary')       { if (typeof renderBestiary==='function')      renderBestiary(); }
  if (tab === 'smithy')         { if (typeof renderSmithy==='function')        renderSmithy(); }
  if (tab === 'sala-personal')  { if (typeof renderSalaPersonal==='function')  renderSalaPersonal(); }
  _setPageBg(_CTAB_BG[tab] || null);
  const activePanel = document.getElementById(`ctab-${tab}`);
  if (activePanel && typeof animCharTabIn === 'function') animCharTabIn(activePanel);
}

function renderIntegrations() {
  if (typeof renderFitWidget  === 'function') renderFitWidget();
}

function toggleCompact() {
  compact = !compact;
  document.getElementById('app').dataset.compact = compact;
  toast('⊟', compact ? 'Modo compacto ON' : 'Modo compacto OFF');
}

/* KEYBOARD */
document.addEventListener('keydown', e => {
  const tag = e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  const key = e.key.toUpperCase();
  if (e.key === ' ') { e.preventDefault(); startTimer(); }
  if (key === 'N') { e.preventDefault(); document.getElementById('qName').focus(); }
  if (key === 'R') resetTimer();
  if (key === 'C') toggleCompact();
  if (key === 'F') toggleFocusMode();
  if (key === 'S') toggleSidebar();
  if (key === 'B') { bulkMode ? exitBulkMode() : enterBulkMode(); }
  if (e.key === '?') { e.preventDefault(); openModal('shortcutsModal'); }
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => {
      if (typeof gsap !== 'undefined') { gsap.killTweensOf(m); gsap.set(m, { clearProps: 'opacity,pointerEvents' }); }
      m.classList.remove('open');
      m.style.pointerEvents = '';
    });
  }
  if (key === '1') switchView('quests');
  if (key === '2') switchView('character');
  if (key === '3') switchView('stats');
  if (key === '4') switchView('achievements');
  if (key === '5') switchView('history');
});
