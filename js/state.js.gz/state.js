﻿/* STATE */
let db;
let hero = null;
let quests = [];
let pomodoros = [];
let timer = { running: false, phase: 'focus', seconds: 25*60, interval: null, duration: 25, pomsDone: 0, _nextPomDouble: false };
let activeFilter = localStorage.getItem('dungeon-filter') || 'all';
let sortMode = localStorage.getItem('dungeon-sort') || 'created';
let compact = false;
let spellState = {};
let xpMultiplier = 1;
let xpMultiplierEnd = 0;
let tagFilter = null;
let dateFilter = 'all';
let historyTypeFilter = 'all';
let pendingDeleteId = null;
let lastCompletedUndo = null;
let heroRace = 'humano';   // populated from hero after loadHero()
let guildName = '';
let webhookUrl = '';
let bulkMode = false;
let bulkSelected = new Set();
let historyPage = 1;
let sidebarCollapsed = false;
let breakDuration = parseInt(localStorage.getItem('dungeon-break-dur') || '5');
let pomGoal = parseInt(localStorage.getItem('dungeon-pom-goal') || '8');
let autoBreak = localStorage.getItem('dungeon-auto-break') !== 'false';
let goals = [];
