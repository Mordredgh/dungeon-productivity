﻿'use strict';

// Capture OAuth callback params before Supabase auto-detects and clears ?code= from the URL
const _oauthParams = new URLSearchParams(window.location.search);

const SUPA_URL = 'https://xibmopqlgjbcypxixnri.supabase.co';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhpYm1vcHFsZ2piY3lweGl4bnJpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM4Nzg2OTUsImV4cCI6MjA5OTQ1NDY5NX0.cvczYn3u44M9UwcLWmKEH4MP-y2qeT_tDvMcHHqb1o0';

const WEATHER = {
  0:{i:'☀️',d:'Cielo despejado'},      1:{i:'🌤️',d:'Mayormente despejado'},
  2:{i:'⛅',d:'Parcialmente nublado'},  3:{i:'☁️',d:'Nublado'},
  45:{i:'🌫️',d:'Niebla'},              48:{i:'🌫️',d:'Niebla helada'},
  51:{i:'🌦️',d:'Llovizna ligera'},     53:{i:'🌦️',d:'Llovizna moderada'},
  55:{i:'🌦️',d:'Llovizna intensa'},    56:{i:'🌧️',d:'Llovizna helada'},
  57:{i:'🌧️',d:'Llovizna helada intensa'},
  61:{i:'🌧️',d:'Lluvia ligera'},       63:{i:'🌧️',d:'Lluvia moderada'},
  65:{i:'🌧️',d:'Lluvia intensa'},      66:{i:'🌧️',d:'Lluvia helada'},
  67:{i:'🌧️',d:'Lluvia helada intensa'},
  71:{i:'🌨️',d:'Nevada ligera'},       73:{i:'🌨️',d:'Nevada moderada'},
  75:{i:'❄️',d:'Nevada intensa'},       77:{i:'❄️',d:'Granizo fino'},
  80:{i:'🌦️',d:'Chubascos ligeros'},   81:{i:'🌧️',d:'Chubascos moderados'},
  82:{i:'⛈️',d:'Chubascos violentos'}, 85:{i:'🌨️',d:'Chubascos de nieve ligeros'},
  86:{i:'❄️',d:'Chubascos de nieve intensos'},
  95:{i:'⛈️',d:'Tormenta eléctrica'},  96:{i:'⛈️',d:'Tormenta con granizo ligero'},
  99:{i:'⛈️',d:'Tormenta con granizo intenso'},
};

const TITLES = [
  'Aprendiz del Gremio','Escudero Inquieto','Explorador del Caos',
  'Guerrero del Enfoque','Cazador de Metas','Mago del Tiempo',
  'Comandante del Gremio','Campeón Legendario','Guardián del Caos',
  'Señor del Caos Productivo',
  'Caballero del Foco','Maestro de Misiones','Archimago del Tiempo',
  'Legado del Dungeon','Heraldo de la Productividad',
  'Conquistador de Hábitos','Gran Maestro del Gremio',
  'Señor de las Runas','Guardián del Umbral','Vanguardia Eterna',
  'Leyenda del Dungeon','Arquitecto del Orden','Fénix del Enfoque',
  'Portador del Caos Sagrado','Centinela Inmortal',
  'Titán de la Voluntad','Oráculo del Dungeon',
  'Caminante entre Mundos','Desterrador del Caos',
  'Maestro del Tiempo Arcano',
  'Señor de los Antiguos','Elegido del Destino',
  'Destructor de Límites','Héroe de los Mil Mundos',
  'Invocador del Poder Último','Archi-Maestro del Dungeon',
  'Portador de la Llama Eterna','Juez del Destino',
  'Custodio del Cosmos','Último Guardián',
  'Leyenda Viviente','Señor del Caos Absoluto',
  'Forjador de Reinos','Maestro Arcano Supremo',
  'El que Trasciende','Señor de la Eternidad',
  'Dios del Tiempo','El Invencible',
  'Leyenda de las Leyendas','Señor del Dungeon Eterno',
];

const XP_TABLE = { main: 100, side: 50, daily: 25, weekly: 75, habit: 20 };
const POM_XP = 15;

/* ── FACCIONES DEL DUNGEON — reputación por tipo de misión ──
   3 rangos por facción, cada rango da bonus pasivo de XP (igual que
   Zonas) en misiones de ese tipo. Rango máximo desbloquea una serie
   de 3 misiones reales al azar (de un pool más grande) — el oro/XP
   bono se entrega al completar las 3. Reclamable de nuevo cada 7 días
   una vez completada la serie anterior (FACTION_RECLAIM_COOLDOWN_MS). */
const FACTION_RECLAIM_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;
const FACTION_DEFS = [
  { id: 'campeones',  type: 'main',   name: 'Orden de los Campeones',   icon: '⚔️', color: '#ef4444',
    desc: 'Forjada por quienes solo aceptan las misiones épicas.',
    ranks: [
      { name: 'Aspirante', xp: 0,    bonus: 0 },
      { name: 'Campeón',   xp: 400,  bonus: 0.05 },
      { name: 'Leyenda',   xp: 1200, bonus: 0.12 },
    ],
    exclusive: {
      stepsPool: [
        'Derrota al Jefe Semanal esta semana',
        'Completa 1 misión Épica pendiente',
        'Mantén tu racha activa 3 días seguidos',
        'Crea y completa 1 misión Épica nueva hoy',
        'Termina el proyecto más grande que tengas abierto',
        'Alcanza el siguiente nivel de tu héroe',
        'Completa 2 misiones Épicas esta semana',
        'Derrota un Jefe con tu mascota sin usar pociones',
        'Cierra una misión Épica vencida hace tiempo',
      ],
      xp: 250, gold: 150 } },
  { id: 'mercaderes', type: 'side',   name: 'Gremio de Mercaderes',     icon: '💼', color: '#f59e0b',
    desc: 'Comerciantes y solucionadores de encargos del reino.',
    ranks: [
      { name: 'Aprendiz', xp: 0,   bonus: 0 },
      { name: 'Socio',    xp: 300, bonus: 0.05 },
      { name: 'Magnate',  xp: 900, bonus: 0.12 },
    ],
    exclusive: {
      stepsPool: [
        'Completa 2 Encargos pendientes',
        'Cierra un Encargo con fecha límite vencida (o el más antiguo)',
        'Crea y completa 1 Encargo nuevo hoy mismo',
        'Completa 3 Encargos en un solo día',
        'Resuelve el Encargo que más llevas posponiendo',
        'Cierra tu bandeja de Encargos a cero por hoy',
        'Completa un Encargo antes del mediodía',
        'Agrega y completa un Encargo urgente',
        'Termina 2 Encargos de baja prioridad acumulados',
      ],
      xp: 150, gold: 300 } },
  { id: 'disciplina', type: 'daily',  name: 'Círculo de la Disciplina', icon: '🔄', color: '#22c55e',
    desc: 'Monjes de la rutina — veneran la búsqueda diaria.',
    ranks: [
      { name: 'Novicio', xp: 0,   bonus: 0 },
      { name: 'Monje',   xp: 250, bonus: 0.05 },
      { name: 'Maestro', xp: 750, bonus: 0.12 },
    ],
    exclusive: {
      stepsPool: [
        'Completa tu Búsqueda Diaria hoy',
        'Completa 2 Búsquedas Diarias más esta semana',
        'Cierra la semana sin fallar ningún día',
        'Completa tu Búsqueda Diaria antes del mediodía',
        'Completa 3 días seguidos de Búsqueda Diaria',
        'Añade una nueva Búsqueda Diaria y complétala hoy',
        'Termina tu Búsqueda Diaria antes de dormir 2 noches seguidas',
        'Completa tus Búsquedas Diarias sin usar pociones de XP',
        'Cierra el día con todas tus Búsquedas Diarias en cero',
      ],
      xp: 100, gold: 80 } },
  { id: 'cronicas',   type: 'weekly', name: 'Consejo de las Crónicas',  icon: '📜', color: '#8b5cf6',
    desc: 'Guardianes de las grandes gestas semanales.',
    ranks: [
      { name: 'Escriba',   xp: 0,    bonus: 0 },
      { name: 'Cronista',  xp: 350,  bonus: 0.05 },
      { name: 'Archivero', xp: 1000, bonus: 0.12 },
    ],
    exclusive: {
      stepsPool: [
        'Completa 1 Crónica Semanal pendiente',
        'Crea una nueva Crónica Semanal y complétala',
        'Revisa la Sala del Trono al cerrar la semana',
        'Completa 2 Crónicas Semanales esta semana',
        'Cierra una Crónica Semanal antes del domingo',
        'Planea la Crónica Semanal de la próxima semana',
        'Termina la Crónica Semanal más antigua pendiente',
        'Completa una Crónica Semanal sin ayuda de bonus',
        'Revisa tu progreso semanal y ajusta tus metas',
      ],
      xp: 200, gold: 200 } },
];

/* ── MISIÓN DEL DÍA — pool curado, seleccionado por seed de fecha ──
   xp/gold fijos, mayores que una daily normal (25 XP / 10 oro) */
const DAILY_SPECIAL_QUESTS = [
  { name:'🌅 Madrugar con propósito',     desc:'Completa tu primera misión antes de las 9am.' },
  { name:'⚔️ Tres victorias seguidas',    desc:'Completa 3 misiones cualquiera hoy.' },
  { name:'📚 Sesión de enfoque profundo', desc:'Completa 1 pomodoro completo sin pausar.' },
  { name:'🛡️ Cero pendientes',           desc:'Termina el día sin misiones vencidas.' },
  { name:'🗡️ Cacería de jefe',           desc:'Ataca al menos 1 vez a cualquier jefe activo.' },
  { name:'🌙 Cierre nocturno',            desc:'Completa una misión después de las 8pm.' },
  { name:'🔥 Mantén la racha viva',       desc:'Completa al menos 1 misión antes de medianoche.' },
  { name:'💎 Misión legendaria',          desc:'Completa cualquier misión de prioridad Épica o superior.' },
  { name:'🧪 Alquimista del día',         desc:'Usa cualquier hechizo o poción.' },
  { name:'🐾 Cuida tu compañero',         desc:'Alimenta o activa a tu mascota.' },
  { name:'📜 Plan del día',               desc:'Crea una misión nueva y complétala el mismo día.' },
  { name:'⚒️ Visita al Herrero',          desc:'Abre el Herrero y revisa tus recetas disponibles.' },
  { name:'🏰 Ronda del Reino',            desc:'Revisa tu Sala del Trono y tus Zonas del Dungeon.' },
  { name:'✝️ Hábito cumplido',            desc:'Completa cualquier hábito positivo hoy.' },
];
const DAILY_SPECIAL_XP   = 60;
const DAILY_SPECIAL_GOLD = 30;

/* ── HITOS DE RACHA — recompensa en oro/XP (no solo logro cosmético) ── */
const STREAK_REWARD_MILESTONES = [
  { days: 3,   xp: 50,   gold: 30   },
  { days: 7,   xp: 120,  gold: 80   },
  { days: 14,  xp: 250,  gold: 150  },
  { days: 21,  xp: 350,  gold: 220  },
  { days: 30,  xp: 500,  gold: 350  },
  { days: 60,  xp: 1000, gold: 700  },
  { days: 100, xp: 2000, gold: 1500 },
  { days: 150, xp: 3000, gold: 2200 },
  { days: 200, xp: 4000, gold: 3000 },
  { days: 365, xp: 8000, gold: 6000 },
];
/* Curva de nivel — cuadrática, no exponencial (rebalanceada 2026-06-30).
   La anterior (100 * 1.5^n compuesto) hacía nivel 50 literalmente
   inalcanzable (~12,700 millones de XP acumulada). Esta apunta a
   ~6-9 meses de juego activo consistente para llegar a nivel 50. */
/* Curva de héroe v2: primeros niveles legibles, nivel medio y alto con peso.
   Antes: 50 + 2×n². Ahora: 80 + 3.5×n² (~1.6× más XP al inicio y ~1.7× al final). */
const LEVEL_FLOOR = 80;
const LEVEL_QUAD  = 3.5;
const THEMES = ['dark', 'light', 'cyber', 'oled', 'parchment'];
const THEME_NAMES = { dark: 'Oscuro', light: 'Claro', cyber: 'Cyber', oled: 'OLED', parchment: 'Pergamino' };

const COMPLETIONS = [
  '¡El enemigo ha caído! La mazmorra tiembla ante tu poder.',
  '¡Victoria épica! Los bardos cantarán tus hazañas esta noche.',
  '¡Misión cumplida! El gremio te saluda con honores.',
  '¡Eres imparable! Tu leyenda crece con cada conquista.',
  '¡Excelente trabajo! El caos retrocede ante ti.',
  '¡La oscuridad huye! Tu determinación es tu arma más poderosa.',
  '¡Tarea destruida! XP añadidos a tu grimorio.',
  '¡Misión completada! El dragón de la procrastinación llora.',
  '¡Increíble! Otro logro grabado en las piedras del gremio.',
  '¡Eso fue épico! El Señor del Caos Productivo está satisfecho.',
  '¡Has avanzado! Cada tarea es un paso hacia la leyenda.',
  '¡Poder desbloqueado! Tu XP crece como la magia arcana.',
  '¡El campeón actúa! Nadie puede detenerte ahora.',
  '¡Victoria! El pergamino de tus logros se extiende sin fin.',
  '¡Perfecto! Hasta los dioses del Olimpo te aplauden.',
  '¡Misión eliminada! El monstruo de las tareas pendientes tiembla.',
  '¡Brillante! Tu clase te hace único en el gremio.',
  '¡Lo hiciste! El universo conspira a tu favor.',
  '¡Asombroso! Mereces una poción de celebración.',
  '¡Leyenda confirmada! La mazmorra es tuya.'
];

const RANDOM_EVENTS = [
  { id:'merchant',  icon:'🧙', title:'Mercader Misterioso',    desc:'Un anciano encapuchado te ofrece conocimiento antiguo a cambio de tu esfuerzo.',         choices:[{label:'Aceptar (+100 XP)',      effect:'xp100'},{label:'Declinar',effect:'none'}], img:'evento_mercader' },
  { id:'treasure',  icon:'💰', title:'Tesoro Olvidado',         desc:'Entre las ruinas del castillo encuentras una bolsa de monedas de oro olvidada.',         choices:[{label:'Tomar el botín (+80🪙)', effect:'gold80'}], img:'evento_tesoro' },
  { id:'blessing',  icon:'✨', title:'Bendición del Gremio',    desc:'Los dioses sonríen sobre ti. Tu próxima misión valdrá el doble de XP y oro.',            choices:[{label:'Recibir la bendición',   effect:'doubleNext'}], img:'evento_bendicion' },
  { id:'riddle',    icon:'🔮', title:'La Esfinge Habla',        desc:'"Quien actúa sin dudar conquista sin parar." La esfinge aumenta tu racha misteriosamente.', choices:[{label:'Resolver acertijo (+1 día de racha)', effect:'streak1'}], img:'evento_esfinge' },
  { id:'tavern',    icon:'🍺', title:'Noche en la Taberna',     desc:'El posadero te invita. Descansas bien entre batallas y recuperas fuerzas.',              choices:[{label:'Descansar (+20 HP)',     effect:'hp20'}], img:'evento_taberna' },
  { id:'dragon',    icon:'🐉', title:'Sombra del Dragón',       desc:'Un dragón negro sobrevuela el reino al amanecer. El Jefe Semanal absorbe su poder.',      choices:[{label:'Prepararse para la batalla', effect:'bossHP50'}], img:'evento_dragon' },
  { id:'scroll',    icon:'📜', title:'Pergamino Antiguo',       desc:'Encuentras sabiduría perdida en la biblioteca del castillo. Las épicas brillan hoy.',     choices:[{label:'Estudiar el pergamino', effect:'mainBonus'}], img:'evento_pergamino' },
  { id:'curse',     icon:'💀', title:'Maldición de Medianoche', desc:'Una sombra oscura te marca. Debes completar 2 misiones antes del final del día.',        choices:[{label:'Aceptar el desafío',    effect:'curse'}], img:'evento_maldicion' },
  { id:'storm',     icon:'⚡', title:'¡Tormenta Arcana!',       desc:'Energía mágica colosal llena el aire. ¡El momento perfecto para actuar con fuerza!',     choices:[{label:'Canalizar la energía (2× XP 30min)', effect:'potion'}], img:'evento_tormenta-arcana' },
  { id:'spirit',    icon:'👻', title:'Espíritu del Héroe Caído', desc:'El fantasma de un héroe caído te ofrece guía. Revive una de tus misiones vencidas.',    choices:[{label:'Aceptar su guía',       effect:'revive'},{label:'Respetar y alejarse', effect:'none'}], img:'evento_espiritu' },
];

const WEATHER_TYPES = {
  clear:   { icon:'☀️',  name:'Día Despejado',   desc:'+10% XP todo el día',                           xpMult:1.1,  goldMult:1.0, img:'clima_despejado' },
  fog:     { icon:'🌫️', name:'Niebla Arcana',    desc:'Sin cambios — el misterio envuelve el reino',   xpMult:1.0,  goldMult:1.0, img:'clima_niebla' },
  storm:   { icon:'⛈️', name:'Gran Tormenta',    desc:'-10% XP pero el Jefe recibe daño doble',        xpMult:0.9,  goldMult:1.0, img:'clima_tormenta' },
  rainbow: { icon:'🌈',  name:'Arcoíris Mágico', desc:'+30% Oro en todas las misiones hoy',            xpMult:1.0,  goldMult:1.3, img:'clima_arcoiris' },
  eclipse: { icon:'🌑',  name:'Eclipse Arcano',  desc:'HP no baja por misiones vencidas hoy',           xpMult:1.0,  goldMult:1.0, img:'clima_eclipse' },
};

const CLASS_SKILLS = {
  mago:     { name:'Transmutación',        icon:'🔮', desc:'La próxima misión side/daily da XP de Épica (100 XP base).' },
  guerrero: { name:'Modo Berserker',       icon:'⚡', desc:'2× XP en todas las misiones durante 30 minutos.' },
  clerigo:  { name:'Resurrección',         icon:'✝️', desc:'Restaura una misión vencida: vuelve a fecha de hoy sin penalización.' },
  picaro:   { name:'Golpe en las Sombras', icon:'🗡️', desc:'Completa automáticamente tu daily más antigua pendiente.' },
  arquero:  { name:'Lluvia de Flechas',    icon:'🏹', desc:'La próxima misión semanal da 3× XP.' },
  fundador: { name:'Visión Estratégica',   icon:'🚀', desc:'+25% XP en las próximas 5 misiones completadas.' },
};

const FAMILIARS = {
  mago:     { emoji:'🦉', name:'Búho Arcano'     },
  guerrero: { emoji:'🐺', name:'Lobo de Batalla' },
  clerigo:  { emoji:'🦊', name:'Zorro Sagrado'   },
  picaro:   { emoji:'🐱', name:'Gato Sombra'     },
  arquero:  { emoji:'🦅', name:'Águila Veloz'    },
  fundador: { emoji:'🐉', name:'Dragón Joven'    },
};

/* ── CLASES SECRETAS ─────────────────────────────────────── */
const SECRET_CLASS_DEFS = [
  { key:'crononauta',     name:'Crononauta',        icon:'⏰', portrait:'char_secreto_crononauta.webp',
    condition:'Completa 100 misiones entre 00:00 y 05:00h',
    bonus:'+15% XP en misiones de madrugada (00:00–05:00h)' },
  { key:'paladin',        name:'Paladín',            icon:'🛡️', portrait:'char_secreto_paladin.webp',
    condition:'Completa 50 misiones con el tag "salud"',
    bonus:'+10% HP extra al completar cualquier misión' },
  { key:'nigromante',     name:'Nigromante',         icon:'💀', portrait:'char_secreto_nigromante.webp',
    condition:'Tu HP llega al mínimo 3 veces (≤10 HP)',
    bonus:'Resucitas con 25 HP en vez de 10 cuando pierdes toda tu salud' },
  { key:'titan',          name:'Titán',              icon:'⛰️', portrait:'char_secreto_titan.webp',
    condition:'Acumula 500 días de actividad total',
    bonus:'+20% XP en misiones épicas, legendarias y míticas' },
  { key:'druida',         name:'Druida del Abismo',  icon:'🌑', portrait:'char_secreto_druida.webp',
    condition:'30 días consecutivos con al menos una misión de madrugada',
    bonus:'+30% XP en misiones completadas entre 00:00 y 05:00h' },
  { key:'estrella-caida', name:'Estrella Caída',     icon:'💫', portrait:'char_secreto_estrella-caida.webp',
    condition:'Desbloquea las otras 5 clases secretas',
    bonus:'+5% a todos los multiplicadores de XP en cualquier misión' },
];

/* ── SETS DE CLASES SECRETAS ─────────────────────────────── */
const SECRET_MATERIAL_DEFS = {
  'crononauta':     { key: 'secret_mat_crononauta', name: 'Fragmento de Hora Congelada', icon: '⏳', color: '#93c5fd' },
  'paladin':        { key: 'secret_mat_paladin',     name: 'Pluma de Juramento Sagrado',  icon: '🪶', color: '#fde68a' },
  'nigromante':     { key: 'secret_mat_nigromante',  name: 'Hueso del Renacer',            icon: '🦴', color: '#6ee7b7' },
  'titan':          { key: 'secret_mat_titan',       name: 'Núcleo de Roca Ancestral',     icon: '🪨', color: '#fbbf24' },
  'druida':         { key: 'secret_mat_druida',      name: 'Perla de Marea Eterna',        icon: '🪬', color: '#67e8f9' },
  'estrella-caida': { key: 'secret_mat_estrella',    name: 'Polvo Estelar',                icon: '✨', color: '#e879f9' },
};

const SECRET_SET_PIECES = [
  { key: 'guantes', name: 'Guantes', matCost: 8,  goldCost: 1500, forgeHours: 24  },
  { key: 'botas',   name: 'Botas',   matCost: 8,  goldCost: 1500, forgeHours: 24  },
  { key: 'grebas',  name: 'Grebas',  matCost: 10, goldCost: 2000, forgeHours: 36  },
  { key: 'casco',   name: 'Casco',   matCost: 12, goldCost: 2500, forgeHours: 48  },
  { key: 'pecho',   name: 'Pecho',   matCost: 18, goldCost: 4000, forgeHours: 72  },
  { key: 'arma',    name: 'Arma',    matCost: 25, goldCost: 6500, forgeHours: 120 },
];

const SECRET_SET_MILESTONES = [
  { at: 20, xp: 500,  gold: 0,   label: '25%' },
  { at: 40, xp: 1000, gold: 500, label: '50%' },
  { at: 60, xp: 2000, gold: 0,   label: '75%' },
];

const SECRET_SET_BONUSES = {
  'crononauta':     'Las misiones vencidas no penalizan HP, solo XP reducido',
  'paladin':        '+1 uso adicional gratuito de hechizo de Curación por día',
  'nigromante':     'Al llegar a 0 HP, una vez por semana resucitas con 25% HP',
  'titan':          '+20% HP Máx permanente',
  'druida':         'Las mascotas no pierden hambre durante 48h tras equipar el set',
  'estrella-caida': '+10% a TODOS los stats simultáneamente',
};

/* ── ÁRBOL DE MAESTRÍA — gastado con puntos de prestige ──────
   1 punto de maestría por cada Ascensión. Cada nodo escala por rango. */
const MASTERY_TREE = [
  { id:'vigor',         name:'Vigor Ancestral',  icon:'❤️', img:'mastery_vigor', maxRank:5, effectPerRank:0.02, desc:'+2% HP máx por rango' },
  { id:'fortuna',       name:'Fortuna Eterna',   icon:'💰', img:'mastery_fortuna', maxRank:5, effectPerRank:0.02, desc:'+2% oro ganado por rango' },
  { id:'persistencia',  name:'Persistencia',     icon:'⏳', img:'mastery_persistencia', maxRank:5, effectPerRank:0.05, desc:'-5% tiempo de forja por rango' },
  { id:'fuerza_bruta',  name:'Fuerza Bruta',     icon:'💪', img:'mastery_fuerza_bruta', maxRank:5, effectPerRank:0.03, desc:'+3% daño de mascota en jefes por rango' },
  { id:'suerte',        name:'Suerte del Gremio', icon:'🍀', img:'mastery_suerte', maxRank:5, effectPerRank:0.02, desc:'+2% drop rate por rango' },
  { id:'voluntad',      name:'Voluntad de Hierro', icon:'🗲', img:'mastery_voluntad', maxRank:3, effectPerRank:1,    desc:'+1 ataque diario contra jefes por rango' },
];
function getMasteryRank(nodeId) {
  if (!hero) return 0;
  try { return JSON.parse(hero.mastery_ranks || '{}')[nodeId] || 0; } catch { return 0; }
}
function getMasteryBonus(nodeId) {
  const node = MASTERY_TREE.find(n => n.id === nodeId);
  if (!node) return 0;
  return getMasteryRank(nodeId) * node.effectPerRank;
}

/* ── MEJORAS PERMANENTES (sumidero de oro funcional) ─────────
   Compra única por id, persistida en hero.gold_upgrades (jsonb array de ids) */
const GOLD_UPGRADES = [
  { id:'forge_slot',  name:'Cola de Forja +1',     icon:'⚒️', img:'upgrade_forge_slot', cost:5000,  desc:'+1 espacio en la cola de forja de sets secretos (máx 3→4)' },
  { id:'forge_slot2', name:'Cola de Forja +1 (II)', icon:'⚒️', img:'upgrade_forge_slot2', cost:12000, desc:'+1 espacio adicional en la cola de forja (4→5)', reqUpgrade:'forge_slot' },
  { id:'drop_rate',   name:'Ojo del Coleccionista', icon:'🔮', img:'upgrade_drop_rate', cost:8000,  desc:'+5% drop rate base en todo el loot de misiones' },
  { id:'gold_boost',  name:'Pacto del Mercader',    icon:'💰', img:'upgrade_gold_boost', cost:10000, desc:'+10% oro permanente en todas las ganancias' },
  { id:'pet_training', name:'Pabellón de Adiestramiento', icon:'🐾', img:'dungeon_sala5', cost:7500, desc:'+10% XP para mascotas bebé y monturas' },
  { id:'war_table', name:'Mesa de Estrategia', icon:'⚔️', img:'dungeon_sala7', cost:18000, desc:'+3 energía de combate por jefe' },
];
function hasGoldUpgrade(id) {
  if (!hero) return false;
  try { return JSON.parse(hero.gold_upgrades || '[]').includes(id); } catch { return false; }
}
function getForgeQueueMax() {
  let max = 3;
  if (hasGoldUpgrade('forge_slot'))  max++;
  if (hasGoldUpgrade('forge_slot2')) max++;
  return max;
}

/* ── COSMÉTICOS — marcos de avatar (sumidero de oro sin afectar balance) ── */
const AVATAR_FRAMES = [
  { id:'bronce',  name:'Marco de Bronce',  icon:'🟤', img:'frame_bronce', cost:1500,  cssClass:'frame-bronce' },
  { id:'plata',   name:'Marco de Plata',   icon:'⚪', img:'frame_plata', cost:4000,  cssClass:'frame-plata' },
  { id:'oro',     name:'Marco de Oro',     icon:'🟡', img:'frame_oro', cost:9000,  cssClass:'frame-oro' },
  { id:'arcano',  name:'Marco Arcano',     icon:'🔮', img:'frame_arcano', cost:15000, cssClass:'frame-arcano' },
];

const GOLD_TABLE = { main:50, side:20, daily:10, weekly:35, habit:8 };

const CDN = 'https://xibmopqlgjbcypxixnri.supabase.co/storage/v1/object/public/assets/';

/* ── GOOGLE OAUTH2 (mismo client ID para Fit + Calendar) ──── */
const GOOGLE_CLIENT_ID    = '631929698326-s30ji937vmgri0spmpup3t21tfje35ci.apps.googleusercontent.com';
const GOOGLE_REDIRECT_URI = 'https://dungeon.mordredgh.com/';
// GOOGLE_CLIENT_SECRET removido del frontend — ahora vive en la Edge Function google-oauth

/* ── ARMAS ───────────────────────────────────────────────── */
const WEAPON_DEFS = [
  { key:'espada', name:'Espada',  icon:'⚔️', slot:'main_hand' },
  { key:'mazo',   name:'Mazo',    icon:'🔨', slot:'main_hand' },
  { key:'baculo', name:'Báculo',  icon:'🪄', slot:'main_hand' },
  { key:'arco',   name:'Arco',    icon:'🏹', slot:'main_hand' },
  { key:'dagas',  name:'Dagas',   icon:'🗡️', slot:'off_hand'  },
  // Armaduras
  { key:'pecho',   name:'Pecho',   icon:'🧱', slot:'body'  },
  { key:'casco',   name:'Casco',   icon:'⛑️', slot:'head'  },
  { key:'botas',   name:'Botas',   icon:'👢', slot:'feet'  },
  { key:'guantes', name:'Guantes', icon:'🧤', slot:'hands' },
  { key:'grebas',  name:'Grebas',  icon:'🦵', slot:'legs'  },
];

/* ── ARMADURAS — stat por pieza y tier ───────────────────── */
// statKey: qué bonus otorga (hpMax=HP máx plana, xpBonus/goldBonus=fracción)
const ARMOR_DEFS = [
  { key:'pecho',   name:'Pecho',   icon:'🧱', slot:'body',  statKey:'hpMax',
    statBase:{ comun:4,  raro:8,    epico:14,   legendario:22,  mitico:38  } },
  { key:'casco',   name:'Casco',   icon:'⛑️', slot:'head',  statKey:'xpBonus',
    statBase:{ comun:.04, raro:.08, epico:.14,  legendario:.22, mitico:.35 } },
  { key:'botas',   name:'Botas',   icon:'👢', slot:'feet',  statKey:'goldBonus',
    statBase:{ comun:.04, raro:.08, epico:.14,  legendario:.22, mitico:.35 } },
  { key:'guantes', name:'Guantes', icon:'🧤', slot:'hands', statKey:'xpBonus',
    statBase:{ comun:.03, raro:.06, epico:.10,  legendario:.16, mitico:.26 } },
  { key:'grebas',  name:'Grebas',  icon:'🦵', slot:'legs',  statKey:'hpMax',
    statBase:{ comun:3,  raro:6,    epico:10,   legendario:16,  mitico:28  } },
];
const WEAPON_TIERS = {
  comun:      { label:'Común',      color:'#9ca3af', xpBonus:0,    goldBonus:0,    hpMax:0  },
  raro:       { label:'Raro',       color:'#60a5fa', xpBonus:0.05, goldBonus:0.05, hpMax:5  },
  epico:      { label:'Épico',      color:'#a855f7', xpBonus:0.10, goldBonus:0.10, hpMax:10 },
  legendario: { label:'Legendario', color:'#f59e0b', xpBonus:0.20, goldBonus:0.15, hpMax:20 },
  mitico:     { label:'Mítico',     color:'#ef4444', xpBonus:0.35, goldBonus:0.25, hpMax:35 },
};
const CRAFT_RECIPES = {
  raro:       { from:'comun',      count:5 },
  epico:      { from:'raro',       count:3 },
  legendario: { from:'epico',      count:3 },
  mitico:     { from:'legendario', count:3 },
};
const FORGE_COOLDOWN_MS = {
  legendario: 24 * 3600 * 1000,
  mitico:     3 * 24 * 3600 * 1000,
};

/* ── SHOP ────────────────────────────────────────────────── */
const SHOP_ITEMS = [
  /* Consumibles */
  { id:'potion',       name:'Poción de Concentración', icon:'⚗️', img:'item_potion.webp',       cost:80,  desc:'2× XP durante 30 minutos',                     category:'consumible' },
  { id:'scroll',       name:'Pergamino de Prórroga',   icon:'📜', img:'item_scroll.webp',        cost:60,  desc:'Extiende el deadline de la misión más urgente', category:'consumible' },
  { id:'amulet',       name:'Amuleto de Protección',   icon:'🧿', img:'item_amulet.webp',        cost:120, desc:'Bloquea la próxima pérdida de HP (1 uso)',      category:'consumible' },
  { id:'xpstone',      name:'Piedra de Sabiduría',     icon:'💠', img:'item_xpstone.webp',       cost:200, desc:'+150 XP instantáneos',                         category:'consumible' },
  { id:'revival',      name:'Poción de Resurrección',  icon:'💊', img:'item_revival.webp',       cost:150, desc:'HP restaurada al máximo al instante',           category:'consumible' },
  { id:'hp_minor',     name:'Poción Menor de HP',      icon:'🧪', img:'item_hp_minor.webp',      cost:35,  desc:'+25 HP al instante',                           category:'consumible' },
  { id:'gold_rush',    name:'Monedas del Mercader',    icon:'💰', img:'item_gold_rush.webp',     cost:80,  desc:'2× Oro en todas las misiones durante 1 hora',   category:'consumible' },
  { id:'boss_shield',  name:'Escudo Anti-Boss',        icon:'🛡️', img:'item_boss_shield.webp',   cost:150, desc:'Bloquea la penalización del Jefe esta semana', category:'consumible' },
  { id:'xp_scroll_sm', name:'Pergamino de Poder',      icon:'📜', img:'item_xp_scroll_sm.webp',  cost:70,  desc:'+75 XP instantáneos',                          category:'consumible' },
  /* Huevos de mascotas */
  { id:'egg_zorro-naturaleza',  name:'Huevo Zorro',   img:'pet_egg_zorro-naturaleza.webp',  cost:200, desc:'Eclosiona con pociones de Zorro',    category:'egg' },
  { id:'egg_pantera-sombra',    name:'Huevo Pantera',  img:'pet_egg_pantera-sombra.webp',    cost:300, desc:'Eclosiona con pociones de Pantera',  category:'egg' },
  { id:'egg_lobo-tormenta',     name:'Huevo Lobo',     img:'pet_egg_lobo-tormenta.webp',     cost:400, desc:'Eclosiona con pociones de Lobo',     category:'egg' },
  { id:'egg_grifo',             name:'Huevo Grifo',    img:'pet_egg_grifo.webp',             cost:500, desc:'Eclosiona con pociones de Grifo',    category:'egg' },
  { id:'egg_dragon-fuego',      name:'Huevo Dragón',   img:'pet_egg_dragon-fuego.webp',      cost:600, desc:'Eclosiona con pociones de Dragón',   category:'egg' },
  { id:'egg_fenix-mitico',      name:'Huevo Fénix',    img:'pet_egg_fenix-mitico.webp',      cost:800,  desc:'Eclosiona con pociones de Fénix',    category:'egg' },
  // egg_rey-tempestad se otorga automáticamente — no aparece en tienda
  /* Fragmentos de hechizo (×5 por compra) */
  { id:'frag_frenzy',        name:'Fragmento de Frenesí',       img:'spell_frenzy.webp',        cost:30,  qty:5, desc:'×5 frags · necesitas 30 para lanzar Frenesí',      category:'fragment' },
  { id:'frag_speed',         name:'Pluma de Velocidad',         img:'spell_speed.webp',         cost:20,  qty:5, desc:'×5 frags · necesitas 20 para lanzar Velocidad',     category:'fragment' },
  { id:'frag_berserker',     name:'Colmillo de Berserker',      img:'spell_berserker.webp',     cost:25,  qty:5, desc:'×5 frags · necesitas 25 para lanzar Berserker',     category:'fragment' },
  { id:'frag_shield',        name:'Fragmento de Escudo',        img:'spell_shield.webp',        cost:15,  qty:5, desc:'×5 frags · necesitas 15 para lanzar Escudo Arcano', category:'fragment' },
  { id:'frag_modo-berserker',name:'Esencia Berserker',          img:'spell_modo-berserker.webp',cost:20,  qty:5, desc:'×5 frags · necesitas 20 para Modo Berserker',       category:'fragment' },
  { id:'frag_healing',       name:'Hierba de Curación',         img:'spell_healing.webp',       cost:10,  qty:5, desc:'×5 frags · necesitas 10 para Curación Mayor',       category:'fragment' },
  { id:'frag_mente-acero',   name:'Cristal de Mente de Acero', img:'spell_mente-acero.webp',   cost:25,  qty:5, desc:'×5 frags · necesitas 25 para Mente de Acero',       category:'fragment' },
  /* Armas (comunes) */
  { id:'weapon_espada', name:'Espada Común',   icon:'⚔️', img:'arma_espada_comun.webp', cost:50, desc:'Arma · mano principal · forjable a Rara (×5)',   category:'armas', weaponKey:'espada', tier:'comun' },
  { id:'weapon_mazo',   name:'Mazo Común',     icon:'🔨', img:'arma_mazo_comun.webp',   cost:50, desc:'Arma · mano principal · forjable a Rara (×5)',   category:'armas', weaponKey:'mazo',   tier:'comun' },
  { id:'weapon_baculo', name:'Báculo Común',   icon:'🪄', img:'arma_baculo_comun.webp', cost:50, desc:'Arma · mano principal · forjable a Rara (×5)',   category:'armas', weaponKey:'baculo', tier:'comun' },
  { id:'weapon_arco',   name:'Arco Común',     icon:'🏹', img:'arma_arco_comun.webp',   cost:50, desc:'Arma · mano principal · forjable a Rara (×5)',   category:'armas', weaponKey:'arco',   tier:'comun' },
  { id:'weapon_dagas',  name:'Dagas Comunes',  icon:'🗡️', img:'arma_dagas_comun.webp',  cost:40, desc:'Arma · mano secundaria · forjable a Rara (×5)', category:'armas', weaponKey:'dagas',  tier:'comun' },
  /* Armaduras (comunes) — forjables igual que armas */
  { id:'armor_pecho',   name:'Pecho Común',    icon:'🧱', img:'arma_pecho_comun.webp',   cost:60, desc:'+4 HP máx · forjable a Rara (×5)', category:'armaduras', weaponKey:'pecho',   tier:'comun' },
  { id:'armor_casco',   name:'Casco Común',    icon:'⛑️', img:'arma_casco_comun.webp',   cost:55, desc:'+4% XP · forjable a Rara (×5)',    category:'armaduras', weaponKey:'casco',   tier:'comun' },
  { id:'armor_botas',   name:'Botas Comunes',  icon:'👢', img:'arma_botas_comun.webp',   cost:55, desc:'+4% Oro · forjable a Rara (×5)',   category:'armaduras', weaponKey:'botas',   tier:'comun' },
  { id:'armor_guantes', name:'Guantes Comunes',icon:'🧤', img:'arma_guantes_comun.webp', cost:50, desc:'+3% XP · forjable a Rara (×5)',    category:'armaduras', weaponKey:'guantes', tier:'comun' },
  { id:'armor_grebas',  name:'Grebas Comunes', icon:'🦵', img:'arma_grebas_comun.webp',  cost:50, desc:'+3 HP máx · forjable a Rara (×5)', category:'armaduras', weaponKey:'grebas',  tier:'comun' },
  /* Pociones de mascota (×1 por compra) */
  { id:'pot_zorro-naturaleza', name:'Poción Zorro',   img:'pet_pocion_zorro-naturaleza.webp', cost:40,  desc:'Alimenta a tu Zorro Gigante',    category:'potion' },
  { id:'pot_pantera-sombra',   name:'Poción Pantera', img:'pet_pocion_pantera-sombra.webp',   cost:55,  desc:'Alimenta a tu Pantera Sombra',   category:'potion' },
  { id:'pot_lobo-tormenta',    name:'Poción Lobo',    img:'pet_pocion_lobo-tormenta.webp',    cost:70,  desc:'Alimenta a tu Lobo Tormenta',    category:'potion' },
  { id:'pot_grifo',            name:'Poción Grifo',   img:'pet_pocion_grifo.webp',            cost:90,  desc:'Alimenta a tu Grifo',            category:'potion' },
  { id:'pot_dragon-fuego',     name:'Poción Dragón',  img:'pet_pocion_dragon-fuego.webp',     cost:110, desc:'Alimenta a tu Dragón de Fuego',  category:'potion' },
  { id:'pot_fenix-mitico',     name:'Poción Fénix',   img:'pet_pocion_fenix-mitico.webp',     cost:140, desc:'Alimenta a tu Fénix Mítico',     category:'potion' },
  { id:'pot_rey-tempestad',    name:'Poción del Rey', img:'pet_pocion_rey-tempestad.webp',    cost:250, desc:'Alimenta al Rey de la Tempestad (desbloquea al max todas)', category:'potion' },
  /* Alimento especial — sube nivel de montura (1→50) */
  { id:'food_zorro-naturaleza', name:'Baya Silvestre',    img:'pet_alimento_zorro-naturaleza.webp', cost:50,  desc:'+50 XP al Zorro Gigante (requiere montura)',    category:'alimento' },
  { id:'food_pantera-sombra',   name:'Carne Nocturna',    img:'pet_alimento_pantera-sombra.webp',   cost:65,  desc:'+60 XP a la Pantera Sombra (requiere montura)', category:'alimento' },
  { id:'food_lobo-tormenta',    name:'Carne de Tormenta', img:'pet_alimento_lobo-tormenta.webp',    cost:80,  desc:'+70 XP al Lobo Tormenta (requiere montura)',    category:'alimento' },
  { id:'food_grifo',            name:'Presa Aérea',       img:'pet_alimento_grifo.webp',            cost:100, desc:'+85 XP al Grifo (requiere montura)',            category:'alimento' },
  { id:'food_dragon-fuego',     name:'Brasa Volcánica',   img:'pet_alimento_dragon-fuego.webp',     cost:125, desc:'+100 XP al Dragón de Fuego (requiere montura)', category:'alimento' },
  { id:'food_fenix-mitico',     name:'Llama Eterna',      img:'pet_alimento_fenix-mitico.webp',     cost:160, desc:'+120 XP al Fénix Mítico (requiere montura)',    category:'alimento' },
  { id:'food_rey-tempestad',    name:'Esencia de Furias', img:'pet_alimento_rey-tempestad.webp',    cost:300, desc:'+200 XP al Rey de la Tempestad (requiere montura)', category:'alimento' },
];

/* ── MASCOTAS ────────────────────────────────────────────── */
const PET_DEFS = [
  // level_req: nivel del héroe para evolucionar bebé→montura
  // food_xp: XP que da cada alimento especial
  // base_stats: stats base de la montura en nivel 1  (atk=% XP, def=+HP máx, spd=% Oro, lck=% loot)
  // stat_gain:  incremento por nivel (atk/spd/lck en %, def en HP flat)
  { key:'zorro-naturaleza', name:'Zorro Gigante',   icon:'🦊', rarity:'común',      eggCost:200, hatch:10, evolve:25,
    level_req:15, food_xp:50,
    base_stats:{ atk:1,  def:2,  spd:1,  lck:1  },
    stat_gain: { atk:.10, def:.20, spd:.10, lck:.10 } },
  { key:'pantera-sombra',   name:'Pantera Sombra',  icon:'🐆', rarity:'poco común', eggCost:300, hatch:10, evolve:25,
    level_req:15, food_xp:60,
    base_stats:{ atk:1,  def:3,  spd:2,  lck:1  },
    stat_gain: { atk:.10, def:.25, spd:.15, lck:.10 } },
  { key:'lobo-tormenta',    name:'Lobo Tormenta',   icon:'🐺', rarity:'raro',       eggCost:400, hatch:15, evolve:30,
    level_req:15, food_xp:70,
    base_stats:{ atk:2,  def:5,  spd:2,  lck:2  },
    stat_gain: { atk:.15, def:.30, spd:.15, lck:.15 } },
  { key:'grifo',            name:'Grifo',           icon:'🦅', rarity:'épico',      eggCost:500, hatch:15, evolve:35,
    level_req:15, food_xp:85,
    base_stats:{ atk:3,  def:7,  spd:3,  lck:3  },
    stat_gain: { atk:.25, def:.40, spd:.20, lck:.20 } },
  { key:'dragon-fuego',     name:'Dragón de Fuego', icon:'🐉', rarity:'legendario', eggCost:600, hatch:20, evolve:40,
    level_req:15, food_xp:100,
    base_stats:{ atk:4,  def:10, spd:4,  lck:4  },
    stat_gain: { atk:.35, def:.50, spd:.30, lck:.30 } },
  { key:'fenix-mitico',     name:'Fénix Mítico',    icon:'🔥', rarity:'mítico',     eggCost:800, hatch:20, evolve:50,
    level_req:15, food_xp:120,
    base_stats:{ atk:6,  def:15, spd:5,  lck:6  },
    stat_gain: { atk:.50, def:.60, spd:.40, lck:.50 } },
  { key:'rey-tempestad',    name:'Rey de la Tempestad', icon:'👑', rarity:'cataclismo', eggCost:0, hatch:0, evolve:100,
    level_req:30, food_xp:200, unlock:'all_pets_max',
    base_stats:{ atk:12, def:30, spd:10, lck:12 },
    stat_gain: { atk:1.0, def:1.0, spd:.80, lck:1.0 } },
];

/* ── JEFES ───────────────────────────────────────────────── */
const BOSS_DEFS = [
  // ── COMÚN ──────────────────────────────────────────────────
  { key:'caballero-esqueleto', name:'Caballero Esqueleto',         rarity:'comun',      hp:80,  seasonal:null, emoji:'💀', element:'Oscuro' },
  { key:'golem-piedra',        name:'Gólem de Piedra',             rarity:'comun',      hp:80,  seasonal:null, emoji:'🗿', element:'Elemental' },
  { key:'ogro-cripta',         name:'Ogro de la Cripta',           rarity:'comun',      hp:100, seasonal:null, emoji:'👹', element:'Normal' },
  { key:'slime-corrosivo',     name:'Slime Corrosivo',             rarity:'comun',      hp:60,  seasonal:null, emoji:'🟢', element:'Elemental' },
  { key:'arana-gigante',       name:'Araña Gigante de Cueva',      rarity:'comun',      hp:70,  seasonal:null, emoji:'🕷️', element:'Oscuro' },
  // ── RARO ───────────────────────────────────────────────────
  { key:'caballero-espectral', name:'Caballero Espectral',         rarity:'raro',       hp:150, seasonal:null, emoji:'👻', element:'Oscuro' },
  { key:'quimera',             name:'Quimera de Tres Cabezas',     rarity:'raro',       hp:160, seasonal:null, emoji:'🐲', element:'Fuego' },
  { key:'wyvern-hielo',        name:'Wyvern de Hielo',             rarity:'raro',       hp:140, seasonal:null, emoji:'🐉', element:'Aéreo' },
  // ── ÉPICO ──────────────────────────────────────────────────
  { key:'golem-cristal',       name:'Gólem de Cristal Arcano',     rarity:'epico',      hp:220, seasonal:null, emoji:'💎', element:'Mágico' },
  { key:'dragon-obsidiana',    name:'Dragón de Obsidiana',         rarity:'epico',      hp:250, seasonal:null, emoji:'🖤', element:'Fuego' },
  { key:'hidra-pesadilla',     name:'Hidra de Pesadilla',          rarity:'epico',      hp:270, seasonal:null, emoji:'🐍', element:'Oscuro' },
  { key:'behemot-vacio',       name:'Behemot del Vacío',           rarity:'epico',      hp:280, seasonal:null, emoji:'🌑', element:'Cataclismo' },
  { key:'custodio-tiempo',     name:'Custodio del Tiempo Roto',    rarity:'epico',      hp:260, seasonal:null, emoji:'⏳', element:'Mágico' },
  // ── LEGENDARIO ─────────────────────────────────────────────
  { key:'demonio-sombras',     name:'Demonio de Sombras',          rarity:'legendario', hp:350, seasonal:null, emoji:'😈', element:'Oscuro' },
  { key:'liche-rey',           name:'Liche Rey Coronado',          rarity:'legendario', hp:400, seasonal:null, emoji:'👑', element:'Oscuro' },
  { key:'serafin-caido',       name:'Serafín Caído',               rarity:'legendario', hp:380, seasonal:null, emoji:'🪽', element:'Aéreo' },
  { key:'titan-magma',         name:'Titán de Magma Ancestral',    rarity:'legendario', hp:420, seasonal:null, emoji:'🌋', element:'Fuego' },
  { key:'devorador-constelaciones', name:'Devorador de Constelaciones', rarity:'legendario', hp:450, seasonal:null, emoji:'🌌', element:'Cataclismo' },
  // ── MÍTICO ─────────────────────────────────────────────────
  { key:'liche-ancestral',     name:'Liche Ancestral',             rarity:'mitico',     hp:500, seasonal:null, emoji:'☠️', element:'Oscuro' },
  { key:'fenix-cenizas',       name:'Fénix de Cenizas Eternas',    rarity:'mitico',     hp:550, seasonal:null, emoji:'🔥', element:'Fuego' },
  { key:'kraken-abisal',       name:'Kraken Abisal',               rarity:'mitico',     hp:600, seasonal:null, emoji:'🐙', element:'Oscuro' },
  { key:'dragon-tormentas',    name:'Dragón Anciano de las Tormentas', rarity:'mitico', hp:580, seasonal:null, emoji:'⛈️', element:'Eléctrico' },
  // ── CATACLISMO ─────────────────────────────────────────────
  { key:'arquitecto-vacio',    name:'El Arquitecto del Vacío',     rarity:'cataclismo', hp:800, seasonal:null, emoji:'🌀', element:'Cataclismo' },
  { key:'la-que-susurra',      name:'La Que Susurra entre Eones',  rarity:'cataclismo', hp:900, seasonal:null, emoji:'👁️', element:'Cataclismo' },
  // ── ESTACIONALES ───────────────────────────────────────────
  { key:'halloween',           name:'Señor de las Sombras',        rarity:'mitico',     hp:500, seasonal:{ month:9,  dayStart:24, dayEnd:31 }, emoji:'🎃', element:'Oscuro' },
  { key:'navidad',             name:'Krampus Arcano',              rarity:'mitico',     hp:500, seasonal:{ month:11, dayStart:20, dayEnd:26 }, emoji:'🎄', element:'Mágico' },
  { key:'anio-nuevo',          name:'Dragón del Tiempo',           rarity:'mitico',     hp:500, seasonal:{ month:11, dayStart:28, dayEnd:31 }, emoji:'🎆', element:'Mágico' },
];

/* ── MATRIZ DE EFECTIVIDAD ELEMENTAL — combate de jefes ──────
   Cada elemento de jefe es débil a 1 tipo de ataque (×1.5) y
   resiste a 1-2 tipos (×0.67). 'Normal' y 'Especial' (ultimates)
   son siempre neutros — no participan de la matriz. */
const BOSS_ELEMENT_CHART = {
  'Fuego':      { weakTo: ['Cataclismo'],            resists: ['Elemental'] },
  'Elemental':  { weakTo: ['Fuego'],                 resists: ['Eléctrico'] },
  'Eléctrico':  { weakTo: ['Cataclismo'],            resists: ['Aéreo'] },
  'Aéreo':      { weakTo: ['Eléctrico'],             resists: ['Elemental'] },
  'Oscuro':     { weakTo: ['Mágico'],                resists: ['Aéreo'] },
  'Mágico':     { weakTo: ['Oscuro'],                resists: ['Normal'] },
  'Cataclismo': { weakTo: ['Mágico'],                resists: ['Fuego', 'Eléctrico'] },
  'Normal':     { weakTo: [],                        resists: [] },
};
function getElementMultiplier(bossElement, moveType) {
  const chart = BOSS_ELEMENT_CHART[bossElement];
  if (!chart || moveType === 'Normal' || moveType === 'Especial') return 1;
  if (chart.weakTo.includes(moveType))   return 1.5;
  if (chart.resists.includes(moveType))  return 0.67;
  return 1;
}

/* ── HABILIDADES DE HÉROE EN COMBATE — 1 uso por batalla ─────
   Independiente de useClassSkill() (esa es maná, fuera de combate).
   power: fracción de boss.maxHp como daño base (antes de elemento). */
const HERO_BATTLE_SKILLS = {
  guerrero: { name:'Golpe Brutal',        icon:'⚔️', type:'Normal', power:0.06,
              desc:'Golpe físico puro — ignora elemento del jefe' },
  mago:     { name:'Ráfaga Arcana',       icon:'🔮', type:'Mágico', power:0.05,
              desc:'Daño mágico — nunca es resistido' },
  clerigo:  { name:'Bendición Curativa',  icon:'✝️', type:'heal',   power:0.36,
              desc:'Restaura 36% del HP máx de tu mascota en vez de atacar' },
  picaro:   { name:'Golpe Certero',       icon:'🗡️', type:'crit',   power:2.0,
              desc:'Crítico garantizado — duplica el daño de tu mejor movimiento' },
  arquero:  { name:'Tiro Preciso',        icon:'🏹', type:'double', power:1.0,
              desc:'Golpea dos veces con tu movimiento básico' },
  fundador: { name:'Visión Estratégica',  icon:'🚀', type:'Normal', power:0.35,
              desc:'Ataque táctico: inflige 35% del HP máximo del jefe' },
};

/* ── EVENTOS ESTACIONALES ───────────────────────────────── */
// month: 0-11 (enero=0). dayStart/dayEnd inclusivos. xpBonus: fracción adicional (0.20 = +20%).
const SEASONAL_EVENTS = [
  // Festividades especiales — mayor prioridad
  { id:'halloween',   icon:'🎃', name:'Noche de Espectros',   desc:'Los muertos susurran poder arcano.',       xpBonus:0.25, color:'#f97316', month:9,  dayStart:25, dayEnd:31 },
  { id:'dia_muertos', icon:'💀', name:'Día de Muertos',        desc:'Los ancestros conceden su bendición.',     xpBonus:0.20, color:'#a855f7', month:10, dayStart:1,  dayEnd:2  },
  { id:'navidad',     icon:'🎄', name:'Festival de Krampus',   desc:'El frío arcano amplifica el esfuerzo.',   xpBonus:0.30, color:'#22d3ee', month:11, dayStart:20, dayEnd:26 },
  { id:'anio_nuevo',  icon:'🎆', name:'Alba del Año Nuevo',    desc:'El año comienza con poder renovado.',      xpBonus:0.25, color:'#facc15', month:11, dayStart:28, dayEnd:31 },
  { id:'reyes',       icon:'⭐', name:'Noche de Reyes',         desc:'Los reyes magos traen XP extra.',          xpBonus:0.20, color:'#f59e0b', month:0,  dayStart:5,  dayEnd:6  },
  // Estaciones (menor prioridad si no hay festividad)
  { id:'primavera',   icon:'🌸', name:'Despertar del Bosque',  desc:'La primavera impulsa el crecimiento.',     xpBonus:0.12, color:'#4ade80', month:null, dayStart:null, dayEnd:null, img:'estacion_primavera',
    season: d => { const m=d.getMonth(),dy=d.getDate(); return (m===2&&dy>=20)||(m===3||m===4)||(m===5&&dy<=20); } },
  { id:'verano',      icon:'🌞', name:'Festival del Sol',      desc:'El calor veraniego forja guerreros.',      xpBonus:0.15, color:'#fbbf24', month:null, dayStart:null, dayEnd:null, img:'estacion_verano',
    season: d => { const m=d.getMonth(),dy=d.getDate(); return (m===5&&dy>=21)||(m===6||m===7)||(m===8&&dy<=22); } },
  { id:'otonio',      icon:'🍂', name:'Cosecha Oscura',         desc:'El otoño trae frutos del dungeon.',        xpBonus:0.10, color:'#fb923c', month:null, dayStart:null, dayEnd:null, img:'estacion_otono',
    season: d => { const m=d.getMonth(),dy=d.getDate(); return (m===8&&dy>=23)||(m===9||m===10)||(m===11&&dy<=20); } },
  { id:'invierno',    icon:'❄️', name:'Solsticio de Invierno', desc:'El frío forja voluntades de acero.',       xpBonus:0.20, color:'#93c5fd', month:null, dayStart:null, dayEnd:null, img:'estacion_invierno',
    season: d => { const m=d.getMonth(),dy=d.getDate(); return (m===11&&dy>=21)||(m===0||m===1)||(m===2&&dy<=19); } },
];

/* ── DROPS AL COMPLETAR MISIÓN ──────────────────────────── */
// chance: probabilidad de que caiga algo. min/max: cantidad de ítems.
const DROP_TABLE = {
  comun:      { chance:0.30, min:1, max:2  },
  normal:     { chance:0.40, min:2, max:3  },
  epico:      { chance:0.60, min:3, max:5  },
  legendario: { chance:0.80, min:5, max:8  },
  mitico:     { chance:1.00, min:8, max:15 },
};
// 60% fragmento de hechizo aleatorio · 40% poción de mascota aleatoria
const SPELL_FRAGMENT_KEYS = ['frenzy','speed','berserker','shield','modo-berserker','healing','mente-acero','rayo-arcano','bola-fuego','maldicion-abismal','tormenta-hielo','furia-dragon'];
const PET_POTION_KEYS     = ['zorro-naturaleza','pantera-sombra','lobo-tormenta','grifo','dragon-fuego','fenix-mitico'];

/* ── HECHIZOS — coste en fragmentos ────────────────────────
   (reemplaza el sistema de cooldown por tiempo)             */
const SPELL_FRAG_COST = {
  frenzy:         30,
  speed:          20,
  berserker:      25,
  shield:         15,
  'modo-berserker': 20,
  healing:        10,
  'mente-acero':       25,
  'rayo-arcano':       15,
  'bola-fuego':        25,
  'maldicion-abismal': 20,
  'tormenta-hielo':    35,
  'furia-dragon':      50,
};

/* ── HABILIDADES DE MASCOTA ──────────────────────────────── */
const PET_ABILITIES = {
  'zorro-naturaleza': {
    egg:   { icon:'🌱', desc:'Bendición silvestre: +20 XP ahora (1/día)',          type:'act_xp',      val:20  },
    baby:  { icon:'🌿', desc:'+5 XP por misión diaria (pasivo)',                   type:'daily_xp',    val:5   },
    mount: { icon:'🌿', desc:'+10 XP por diaria · Activo: +40 XP (1/día)',         type:'daily_xp',    val:10  },
  },
  'pantera-sombra': {
    egg:   { icon:'🌑', desc:'Instinto oscuro: próxima misión 2× XP (1/día)',      type:'act_double',  val:1   },
    baby:  { icon:'🌑', desc:'20% chance de 2× XP en secundarias (pasivo)',        type:'side_crit',   val:0.20},
    mount: { icon:'🌑', desc:'35% chance 2× · Activo: doble próxima misión (1/día)',type:'side_crit',  val:0.35},
  },
  'lobo-tormenta': {
    egg:   { icon:'⚡', desc:'Aullido: inflige 20 de daño al jefe ahora (1/día)',  type:'act_boss',    val:20  },
    baby:  { icon:'⚡', desc:'+25% daño al jefe semanal (pasivo)',                 type:'boss_dmg',    val:1.25},
    mount: { icon:'⚡', desc:'+50% daño · Activo: -50 HP al jefe ahora (1/día)',   type:'boss_dmg',    val:1.50},
  },
  'grifo': {
    egg:   { icon:'🦅', desc:'Vuelo ascendente: +25 XP ahora (1/día)',             type:'act_xp',      val:25  },
    baby:  { icon:'🍅', desc:'+15 XP por pomodoro completado (pasivo)',             type:'pom_xp',      val:15  },
    mount: { icon:'🍅', desc:'+30 XP pom · Activo: +50 XP ahora (1/día)',          type:'pom_xp',      val:30  },
  },
  'dragon-fuego': {
    egg:   { icon:'🔥', desc:'Aliento primigenio: +30 XP ahora (1/día)',           type:'act_xp',      val:30  },
    baby:  { icon:'🔥', desc:'+20% XP en misiones épicas y superiores (pasivo)',   type:'epic_xp',     val:0.20},
    mount: { icon:'🔥', desc:'+35% XP global · Activo: 2× XP 30 min (1/día)',      type:'all_xp',      val:0.35},
  },
  'fenix-mitico': {
    egg:   { icon:'✨', desc:'Ceniza sagrada: +15 HP ahora (1/día)',               type:'act_hp',      val:15  },
    baby:  { icon:'✨', desc:'+5 HP al completar misión principal (pasivo)',        type:'main_hp',     val:5   },
    mount: { icon:'✨', desc:'+10 HP principal · Activo: HP al máximo (1/día)',     type:'main_hp_shield',val:10},
  },
};

const BOSS_NAMES = [
  'Dragón de la Procrastinación','Hidra del Caos','Liche del Tiempo Perdido',
  'Gólem de las Deudas','Gorgona del Desenfoque','Fénix Oscuro del Agotamiento',
  'Vampiro de la Energía','Troll de las Distracciones','Demonio de la Pereza',
  'Espectro del Miedo al Fracaso',
];

const PROPHECY_TEMPLATES = [
  (n, s) => `El Oráculo ve esta semana ${n} grandes batallas que definirán al campeón. Solo el héroe con racha de ${s} días o más recibirá la gloria eterna del gremio.`,
  (n, s) => `Las estrellas revelan: ${n} épicas misiones aguardan al guerrero esta semana. Quien mantenga una racha de ${s} días conquistará poderes ocultos.`,
  (n, s) => `La profecía habla: quien derrote al Jefe Semanal y complete ${n} misiones antes del domingo, recibirá el favor de los dioses por ${s} días más.`,
];

const ACHIEVEMENT_DEFS = [
  // ── Combate ──
  { id: 'first_quest',    icon: '🗡️',  name: 'Primera Sangre',    desc: 'Completa tu primera misión',      cond: h => h._completed >= 1, img:'logro_primera-sangre' },
  { id: 'ten_quests',     icon: '⚔️',  name: 'Veterano',          desc: 'Completa 10 misiones',            cond: h => h._completed >= 10, img:'logro_veterano' },
  { id: 'fifty_quests',   icon: '🏆',  name: 'Leyenda',           desc: 'Completa 50 misiones',            cond: h => h._completed >= 50, img:'logro_leyenda' },
  { id: 'quest_200',      icon: '⚔️🔥', name: 'Dios de la Guerra', desc: 'Completa 200 misiones',          cond: h => h._completed >= 200, img:'logro_dios-guerra' },
  { id: 'quest_500',      icon: '💀',  name: 'Exterminador',      desc: 'Completa 500 misiones',           cond: h => h._completed >= 500, img:'logro_exterminador' },
  // ── Progresión ──
  { id: 'first_level',    icon: '⬆️',  name: 'En Ascenso',        desc: 'Alcanza nivel 2',                 cond: h => h._level >= 2, img:'logro_en-ascenso' },
  { id: 'level_five',     icon: '🌟',  name: 'Élite',             desc: 'Alcanza nivel 5',                 cond: h => h._level >= 5, img:'logro_elite' },
  { id: 'level_ten',      icon: '👑',  name: 'Señor del Caos',    desc: 'Alcanza nivel 10',                cond: h => h._level >= 10, img:'logro_senor-caos' },
  { id: 'level_fifteen',  icon: '🔮',  name: 'Archimago',         desc: 'Alcanza nivel 15',                cond: h => h._level >= 15, img:'logro_archimago' },
  { id: 'level_twenty',   icon: '🌌',  name: 'Ascendido',         desc: 'Alcanza nivel 20',                cond: h => h._level >= 20, img:'logro_ascendido' },
  { id: 'thousand_xp',    icon: '💰',  name: 'Rico en Poder',     desc: 'Acumula 1000 XP total',           cond: h => (h.xp_total || 0) >= 1000, img:'logro_rico-poder' },
  { id: 'xp_5k',          icon: '💎',  name: 'Tesoro Arcano',     desc: 'Acumula 5,000 XP total',          cond: h => (h.xp_total || 0) >= 5000, img:'logro_tesoro-arcano' },
  { id: 'xp_25k',         icon: '🌠',  name: 'Maestro del Poder', desc: 'Acumula 25,000 XP total',         cond: h => (h.xp_total || 0) >= 25000, img:'logro_maestro-poder' },
  // ── Pomodoro ──
  { id: 'first_pom',      icon: '🍅',     name: 'Primer Pomodoro',    desc: 'Completa tu primer pomodoro',   cond: h => h._pomodoros >= 1, img:'logro_primer-pomodoro' },
  { id: 'ten_poms',       icon: '🍅🍅',   name: 'Maestro del Tiempo', desc: 'Completa 10 pomodoros',         cond: h => h._pomodoros >= 10, img:'logro_maestro-tiempo' },
  { id: 'pom_25',         icon: '⏱️',    name: 'Incansable',         desc: 'Completa 25 pomodoros',         cond: h => (h.pomodoros_done || 0) >= 25, img:'logro_incansable' },
  { id: 'pom_50',         icon: '🕰️',    name: 'Cronista',           desc: 'Completa 50 pomodoros',         cond: h => (h.pomodoros_done || 0) >= 50, img:'logro_cronista' },
  { id: 'pom_100',        icon: '⌛',    name: 'Señor del Tiempo',   desc: 'Completa 100 pomodoros',        cond: h => (h.pomodoros_done || 0) >= 100, img:'logro_señor-tiempo' },
  { id: 'pom_250',        icon: '🌀',    name: 'Tiempo Infinito',    desc: 'Completa 250 pomodoros',        cond: h => (h.pomodoros_done || 0) >= 250, img:'logro_tiempo-infinito' },
  // ── Rachas ──
  { id: 'streak_3',       icon: '🔥',    name: 'En Llamas',          desc: 'Racha de 3 días',               cond: h => (h.longest_streak || 0) >= 3, img:'logro_en-llamas' },
  { id: 'streak_7',       icon: '🔥🔥',  name: 'Semana Épica',       desc: 'Racha de 7 días',               cond: h => (h.longest_streak || 0) >= 7, img:'logro_semana-epica' },
  { id: 'streak_14',      icon: '🔥💫',  name: 'Fortuna Continua',   desc: 'Racha de 14 días',              cond: h => (h.longest_streak || 0) >= 14, img:'logro_streak_14' },
  { id: 'streak_30',      icon: '💎',    name: 'Indestructible',     desc: 'Racha de 30 días',              cond: h => (h.longest_streak || 0) >= 30, img:'logro_indestructible' },
  { id: 'streak_60',      icon: '🌙',    name: 'Monje del Dungeon',  desc: 'Racha de 60 días',              cond: h => (h.longest_streak || 0) >= 60, img:'logro_streak_60' },
  { id: 'streak_100',     icon: '☀️',   name: 'Eterno',             desc: 'Racha de 100 días',             cond: h => (h.longest_streak || 0) >= 100, img:'logro_eterno' },
  // ── Épicas ──
  { id: 'first_main',     icon: '⭐',    name: 'Misión Mayor',       desc: 'Completa una misión principal',  cond: h => (h._main_done || 0) >= 1, img:'logro_first_main' },
  { id: 'five_main',      icon: '⭐⭐',  name: 'Héroe Principal',    desc: 'Completa 5 misiones principales', cond: h => (h._main_done || 0) >= 5, img:'logro_five_main' },
  { id: 'main_25',        icon: '🗺️',   name: 'Conquistador',       desc: 'Completa 25 misiones principales', cond: h => (h._main_done || 0) >= 25, img:'logro_main_25' },
  // ── Magia ──
  { id: 'spell_cast',     icon: '✨',   name: 'Arcano',             desc: 'Lanza tu primer hechizo',        cond: h => (h._spells_cast || 0) >= 1, img:'logro_spell_cast' },
  // ── Salud ──
  { id: 'full_hp',        icon: '❤️',   name: 'Inquebrantable',     desc: 'Mantén HP al máximo',            cond: h => (h.hp || 0) >= (h.hp_max || 100), img:'logro_full_hp' },
  // ── Oro ──
  { id: 'gold_500',       icon: '🪙',   name: 'Mercader',           desc: 'Acumula 500 de oro',             cond: h => (h.gold || 0) >= 500, img:'logro_mercader' },
  { id: 'gold_2000',      icon: '💳',   name: 'Banquero del Gremio', desc: 'Acumula 2,000 de oro',          cond: h => (h.gold || 0) >= 2000, img:'logro_banquero' },
  { id: 'gold_10k',       icon: '🤑',   name: 'Plutócrata',         desc: 'Acumula 10,000 de oro',          cond: h => (h.gold || 0) >= 10000, img:'logro_plutocrata' },

  // ── Logros ocultos — la descripción y nombre son "???" hasta desbloquear ──
  { id: 'h_madrugador',  icon: '🌅', name: 'El Madrugador',       desc: 'Completa una misión antes de las 7am',   hidden: true, img:'logro_madrugador',
    cond: () => (quests||[]).some(q => q.done && q.done_at && new Date(q.done_at).getHours() < 7) },
  { id: 'h_nocturno',    icon: '🦇', name: 'Criatura de la Noche', desc: 'Completa una misión después de las 11pm', hidden: true, img:'logro_nocturno',
    cond: () => (quests||[]).some(q => q.done && q.done_at && new Date(q.done_at).getHours() >= 23) },
  { id: 'h_maldito',     icon: '💀', name: 'El Número Maldito',   desc: 'Llega exactamente al nivel 13',          hidden: true, img:'logro_h_maldito',
    cond: h => h._level >= 13 },
  { id: 'h_dia_gloria',  icon: '⚡', name: 'Día de Gloria',        desc: 'Completa 5 misiones en un solo día',    hidden: true, img:'logro_dia-gloria',
    cond: () => { const c={}; (quests||[]).filter(q=>q.done&&q.done_at).forEach(q=>{const d=q.done_at.split('T')[0];c[d]=(c[d]||0)+1;}); return Object.values(c).some(v=>v>=5); } },
  { id: 'h_renacido',    icon: '⭐', name: 'El Renacido',          desc: 'Consigue tu primer Prestige',            hidden: true, img:'logro_renacido',
    cond: h => (h.prestige || 0) >= 1 },
  { id: 'h_domingo',     icon: '🌞', name: 'Guerrero del Domingo', desc: 'Completa 5 misiones en domingo',        hidden: true, img:'logro_guerrero-domingo',
    cond: () => (quests||[]).filter(q=>q.done&&q.done_at&&new Date(q.done_at).getDay()===0).length >= 5 },
  { id: 'h_equilibrio',  icon: '⚖️', name: 'Equilibrio Total',    desc: 'Completa los 4 tipos de misión en un mismo día', hidden: true,
    cond: () => { const m={}; (quests||[]).filter(q=>q.done&&q.done_at).forEach(q=>{const d=q.done_at.split('T')[0];if(!m[d])m[d]=new Set();m[d].add(q.type);}); return Object.values(m).some(s=>s.has('main')&&s.has('side')&&s.has('daily')&&s.has('weekly')); } },
  { id: 'h_atributos',   icon: '💪', name: 'El Completo',          desc: 'Alcanza 20 puntos de atributos en total', hidden: true,
    cond: h => (h.str||0)+(h.intel||0)+(h.dex||0)+(h.con||0)+(h.wis||0)+(h.cha||0) >= 20 },
  { id: 'h_racha21',     icon: '🔥', name: 'Tres Semanas',         desc: 'Mantén una racha de 21 días',            hidden: true,
    cond: h => (h.longest_streak||0) >= 21 },
  { id: 'h_xp10k',       icon: '🌠', name: 'Diez Mil',             desc: 'Acumula 10,000 XP total',                hidden: true,
    cond: h => (h.xp_total||0) >= 10000 },
  { id: 'h_ultimo_seg',  icon: '⏰', name: 'El Último Segundo',    desc: 'Completa una misión entre las 23:50 y la medianoche', hidden: true,
    cond: () => (quests||[]).some(q=>q.done&&q.done_at&&new Date(q.done_at).getHours()===23&&new Date(q.done_at).getMinutes()>=50) },
  { id: 'h_triple_main', icon: '🗡️', name: 'Triple Amenaza',      desc: 'Completa 3 misiones principales en un día', hidden: true, img:'logro_triple-amenaza',
    cond: () => { const c={}; (quests||[]).filter(q=>q.done&&q.done_at&&q.type==='main').forEach(q=>{const d=q.done_at.split('T')[0];c[d]=(c[d]||0)+1;}); return Object.values(c).some(v=>v>=3); } },
  { id: 'h_zona_legend', icon: '🏅', name: 'Guardián de Zona',     desc: 'Alcanza rango Campeón en cualquier Zona del Dungeon', hidden: true,
    cond: () => { try { if(typeof calcZoneXP!=='function'||typeof ZONES==='undefined')return false; const x=calcZoneXP(); return ZONES.some(z=>(x[z.id]||0)>=z.thresholds[2]); } catch{return false;} } },
  { id: 'h_pom_dia',     icon: '🍅', name: 'Maratón Rojo',         desc: 'Completa 4 pomodoros en un solo día',    hidden: true, img:'logro_maraton-rojo',
    cond: () => { const c={}; (pomodoros||[]).filter(p=>p.started_at).forEach(p=>{const d=p.started_at.split('T')[0];c[d]=(c[d]||0)+1;}); return Object.values(c).some(v=>v>=4); } },
  { id: 'h_habito10',    icon: '🌿', name: 'Forjado en Hierro',    desc: 'Completa el mismo hábito positivo 10 veces', hidden: true, img:'logro_forjado-hierro',
    cond: h => { try { const hist=JSON.parse(h.habit_history||'{}'); return Object.values(hist).some(arr=>Array.isArray(arr)&&arr.length>=10); } catch{return false;} } },
];
