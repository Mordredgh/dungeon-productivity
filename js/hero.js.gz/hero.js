﻿/* HERO */
async function loadHero() {
  const { data: { user: authUser } } = await db.auth.getUser();
  if (!authUser) throw new Error('No hay una sesión válida para cargar el héroe.');

  const { data, error: loadError } = await db.from('dungeon_heroes')
    .select('*')
    .eq('user_id', authUser.id)
    .limit(1);
  if (loadError) throw loadError;
  if (data && data.length) {
    hero = data[0];
  } else {
    const { data: nh, error: createError } = await db.from('dungeon_heroes').insert({
      user_id: authUser.id,
      name: 'Héroe sin nombre', hero_class: 'guerrero', avatar: '🧙',
      xp: 0, xp_total: 0, level: 1, hp: 100, hp_max: 100,
      streak: 0, longest_streak: 0, achievements: '[]', spells: '{}'
    }).select().single();
    if (createError) throw createError;
    hero = nh;
  }
  deriveHero();
  // La curva nueva nunca baja el nivel ya obtenido: ajusta solo el total mínimo
  // requerido para conservarlo, una vez por héroe y sin columna adicional.
  const savedLevel = Math.max(1, hero.level || hero._level || 1);
  const minXPForSavedLevel = xpForLevel(savedLevel - 1);
  if ((hero.xp_total || 0) < minXPForSavedLevel) {
    const delta = minXPForSavedLevel - (hero.xp_total || 0);
    const { data: curveData, error: curveError } = await db.rpc('grant_dungeon_currency', { p_source: 'level_curve_migration', p_xp: delta });
    const curveR = Array.isArray(curveData) ? curveData[0] : curveData;
    if (!curveError && curveR) hero.xp_total = curveR.xp_total;
    deriveHero();
  }
  // Init global state from hero record
  heroRace   = hero.race        || 'humano';
  guildName  = hero.guild_name  || '';
  webhookUrl = hero.webhook_url || '';
  // One-time gold migration from localStorage
  const _localGold = parseInt(localStorage.getItem('dungeon-gold') || '0');
  if (_localGold > 0 && !(hero.gold > 0)) {
    setGold(_localGold, 'legacy_migration');
  }
  localStorage.removeItem('dungeon-gold');
  try { localStorage.setItem('dungeon-cache-hero', JSON.stringify(hero)); } catch {}
  applyClassTheme();
  if (!hero.race) setTimeout(() => window.openInitialIdentitySelection?.(), 0);
}

function applyClassTheme() {
  if (!hero) return;
  document.documentElement.dataset.heroClass = hero.hero_class || 'guerrero';
}

function deriveHero() {
  hero._level = calcLevel(hero.xp_total || 0);
  hero._completed = hero.quests_done || 0;
  hero._pomodoros = hero.pomodoros_done || 0;
  hero._main_done = hero.main_done || 0;
  hero._spells_cast = hero.spells_cast || 0;
  try { spellState = JSON.parse(hero.spells || '{}'); } catch { spellState = {}; }
}

async function saveHero(patch) {
  if (!hero?.id) return false;
  const before = { ...hero };
  Object.assign(hero, patch);
  deriveHero();
  const { data: { user: authUser } } = await db.auth.getUser();
  if (!authUser) return false;
  const { error } = await db.from('dungeon_heroes').update(patch)
    .eq('id', hero.id)
    .eq('user_id', authUser.id);
  if (error) {
    Object.assign(hero, before);
    deriveHero();
    try { renderHeroUI(); } catch {}
    toast('⚠️', 'No se pudo guardar tu progreso. Revisa la conexión e inténtalo de nuevo.');
    return false;
  }
  try { localStorage.setItem('dungeon-cache-hero', JSON.stringify(hero)); } catch {}
  return true;
}

function calcLevel(totalXP) {
  let lvl = 1;
  while (lvl < 50 && totalXP >= xpForLevel(lvl)) lvl++;
  return Math.min(lvl, 50);
}

function canPrestige() { return !!hero && (hero._level || 1) >= 50; }

const CLASS_CHANGE_GOLD_COST = 20000;
const CLASS_CHANGE_COOLDOWN_MS = 7 * 24 * 60 * 60 * 1000;

function _heroSkillTree() {
  try { return JSON.parse(hero?.skill_tree || '{}'); } catch { return {}; }
}

// El metadato viaja con skill_tree, una columna JSON ya persistente. Las claves
// con "__" son de sistema y nunca se interpretan como habilidades aprendidas.
function getHeroProgression() {
  const meta = _heroSkillTree().__progression || {};
  return {
    raceLocked: meta.raceLocked ?? !!hero?.race,
    classFreeChangeUsed: !!meta.classFreeChangeUsed,
    classChangeCooldownUntil: Number(meta.classChangeCooldownUntil || 0),
    lastPrestigeAt: Number(meta.lastPrestigeAt || 0),
  };
}

function getClassChangeQuote(nextClass, now = Date.now()) {
  if (!hero || !nextClass || nextClass === hero.hero_class) return { allowed:false, reason:'same-class' };
  const progression = getHeroProgression();
  if (progression.classChangeCooldownUntil > now) {
    return { allowed:false, reason:'cooldown', until:progression.classChangeCooldownUntil };
  }
  return {
    allowed:true,
    free:!progression.classFreeChangeUsed,
    cost:progression.classFreeChangeUsed ? CLASS_CHANGE_GOLD_COST : 0,
  };
}

function buildClassReset(nextProgression) {
  const current = _heroSkillTree();
  const refunded = Object.entries(current)
    .filter(([id, learned]) => !id.startsWith('__') && learned === true).length;
  const permanent = Object.fromEntries(Object.entries(current).filter(([id]) => id.startsWith('__') && id !== '__progression'));
  return {
    refunded,
    skillPoints:(hero?.skill_points || 0) + refunded,
    tree:{ ...permanent, __progression:nextProgression },
  };
}

function _formatCooldown(until) {
  const hours = Math.ceil(Math.max(0, until - Date.now()) / 3600000);
  return `${Math.floor(hours / 24)}d ${hours % 24}h`;
}

/* Curva de diminishing returns — lineal +5%/prestige hasta el 10,
   luego se aplana asintóticamente hacia +100% adicional (nunca lo alcanza). */
function getPrestigeXPBonus(prestige) {
  if (!prestige) return 0;
  if (prestige <= 10) return prestige * 0.05;
  return 0.5 + (1 - Math.exp(-(prestige - 10) * 0.04)) * 0.5;
}

const PRESTIGE_DOCTRINES = {
  conquistador: { name:'Senda del Conquistador', desc:'+3% daño contra jefes por ascensión', bonus:'boss_dmg', value:.03 },
  arcanista:    { name:'Senda del Arcanista', desc:'-3% coste de maná por ascensión', bonus:'mana', value:.03 },
  mercader:     { name:'Senda del Mercader', desc:'+3% oro ganado por ascensión', bonus:'gold', value:.03 },
};
function _masteryRanks() { try { return JSON.parse(hero?.mastery_ranks || '{}'); } catch { return {}; } }
function getPrestigeDoctrine() { return PRESTIGE_DOCTRINES[_masteryRanks().__doctrine] || null; }
function getPrestigeDoctrineBonus(type) {
  const doctrine = getPrestigeDoctrine();
  return doctrine?.bonus === type ? doctrine.value * (hero?.prestige || 0) : 0;
}
function openPrestigeDoctrine() {
  const modal = document.createElement('div');
  modal.className = 'prestige-choice-overlay';
  modal.id = 'prestigeDoctrineModal';
  modal.innerHTML = `<section class="prestige-choice-card" role="dialog" aria-modal="true" aria-label="Elige doctrina de ascensión"><span>PRIMERA ASCENSIÓN</span><h2>Elige tu senda permanente</h2><p>Esta decisión define el bono de todas tus ascensiones futuras.</p><div class="prestige-choice-grid">${Object.entries(PRESTIGE_DOCTRINES).map(([id, def]) => `<button onclick="choosePrestigeDoctrine('${id}')"><b>${def.name}</b><small>${def.desc}</small></button>`).join('')}</div></section>`;
  document.body.appendChild(modal);
}
async function choosePrestigeDoctrine(id) {
  if (!PRESTIGE_DOCTRINES[id] || getPrestigeDoctrine()) return;
  const ranks = _masteryRanks();
  ranks.__doctrine = id;
  await saveHero({ mastery_ranks: JSON.stringify(ranks) });
  document.getElementById('prestigeDoctrineModal')?.remove();
  await doPrestige();
}
window.choosePrestigeDoctrine = choosePrestigeDoctrine;

async function doPrestige() {
  if (!canPrestige()) return;
  if (!getPrestigeDoctrine()) { openPrestigeDoctrine(); return; }
  openPrestigeConfirmation();
}

let _prestigeRaceChoice = null;
function openPrestigeConfirmation() {
  document.getElementById('prestigeConfirmModal')?.remove();
  const currentRace = heroRace || hero.race || 'humano';
  const choices = Object.entries(typeof RACE_LABELS === 'undefined' ? {} : RACE_LABELS)
    .filter(([id]) => id !== currentRace);
  const modal = document.createElement('div');
  modal.className = 'prestige-choice-overlay';
  modal.id = 'prestigeConfirmModal';
  modal.innerHTML = `<section class="prestige-choice-card progression-confirm" role="dialog" aria-modal="true" aria-label="Confirmar prestigio">
    <span>ASCENSIÓN · NIVEL 50</span><h2>Renace bajo otra raza</h2>
    <p>Conservas logros, colección, arte, muebles, cosméticos, oro y maestrías. Se reinician nivel, XP, atributos y habilidades.</p>
    <div class="prestige-choice-grid progression-race-grid">${choices.map(([id, def]) => `<button type="button" data-race="${id}" onclick="choosePrestigeRace('${id}')"><img src="images/${def.img}.webp" alt=""><b>${def.name}</b><small>${def.bonus || ''}</small></button>`).join('')}</div>
    <div class="progression-confirm-actions"><button type="button" class="btn btn-ghost" onclick="document.getElementById('prestigeConfirmModal').remove()">Cancelar</button><button type="button" class="btn btn-primary" onclick="confirmPrestige()">Confirmar Prestigio</button></div>
  </section>`;
  document.body.appendChild(modal);
}
function choosePrestigeRace(race) {
  if (!RACE_LABELS?.[race]) return;
  _prestigeRaceChoice = race;
  document.querySelectorAll('#prestigeConfirmModal [data-race]').forEach(el => el.classList.toggle('progression-picked', el.dataset.race === race));
}
async function confirmPrestige() {
  if (!canPrestige() || !getPrestigeDoctrine()) return;
  const race = _prestigeRaceChoice;
  if (!RACE_LABELS?.[race]) { toast('🔒', 'Elige la raza con la que renacerás.'); return; }
  const newPrestige  = (hero.prestige || 0) + 1;
  const newMastery   = (hero.mastery_points || 0) + 1;
  const progression = { ...getHeroProgression(), raceLocked:true, lastPrestigeAt:Date.now() };
  const reset = buildClassReset(progression);
  await saveHero({
    prestige:newPrestige, mastery_points:newMastery, xp_total:0, xp:0, level:1,
    str:0, intel:0, agi:0, con:0, lck:0, attr_points:0, hp:100, hp_max:100,
    skill_points:0, skill_tree:JSON.stringify(reset.tree), race,
  });
  heroRace = race;
  _prestigeRaceChoice = null;
  document.getElementById('prestigeConfirmModal')?.remove();
  const pct = Math.round(getPrestigeXPBonus(newPrestige) * 100);
  toast('⭐', `¡Ascensión ${newPrestige}! Renaciste como ${RACE_LABELS[race].name} · +${pct}% XP permanente.`);
  spawnConfetti();
  renderHeroUI();
  if (typeof renderCharacterSheet === 'function') renderCharacterSheet();
}
window.choosePrestigeRace = choosePrestigeRace;
window.confirmPrestige = confirmPrestige;

async function spendMasteryPoint(nodeId) {
  if (!hero || (hero.mastery_points || 0) <= 0) return;
  const node = typeof MASTERY_TREE !== 'undefined' ? MASTERY_TREE.find(n => n.id === nodeId) : null;
  if (!node) return;
  const ranks = (() => { try { return JSON.parse(hero.mastery_ranks || '{}'); } catch { return {}; } })();
  const current = ranks[nodeId] || 0;
  if (current >= node.maxRank) { toast('✅', `${node.name} ya está al máximo.`); return; }
  ranks[nodeId] = current + 1;
  await saveHero({ mastery_points: (hero.mastery_points || 0) - 1, mastery_ranks: JSON.stringify(ranks) });
  toast(node.icon, `${node.name} mejorado a rango ${current + 1}/${node.maxRank}.`);
  if (typeof renderCharacterSheet === 'function') renderCharacterSheet();
  renderHeroUI();
}

function xpForLevel(lvl) {
  if (lvl <= 0) return 0;
  let total = 0;
  for (let i = 1; i <= lvl; i++) total += Math.round(LEVEL_FLOOR + LEVEL_QUAD * i * i);
  return total;
}

const _CLASS_XP = {
  mago:     { _: 1.1 },
  guerrero: { main: 1.1 },
  picaro:   { side: 1.1 },
  arquero:  { weekly: 1.1 },
  clerigo:  { daily: 1.05 },
  fundador: {},
};
function classXPBonus(type) {
  const cls   = hero?.hero_class || 'guerrero';
  const entry = _CLASS_XP[cls] || {};
  let bonus   = entry[type] || entry['_'] || 1;
  if ((heroRace || 'humano') === 'humano') bonus *= 1.1;
  if (hero) {
    if (type === 'main' && hero.str)                         bonus *= 1 + hero.str   * 0.01;
    if ((type === 'side' || type === 'daily') && hero.intel) bonus *= 1 + hero.intel * 0.01;
    if (hero.prestige)                                       bonus *= 1 + getPrestigeXPBonus(hero.prestige);
  }
  // Bono de set Estrella Caída: +10% a todos los multiplicadores de XP
  if (typeof isSecretSetComplete === 'function' && isSecretSetComplete('estrella-caida')) bonus *= 1.10;
  return bonus;
}

async function addXP(amount, type, sourceEl) {
  if (xpMultiplierEnd && Date.now() > xpMultiplierEnd) { xpMultiplier = 1; xpMultiplierEnd = 0; }
  const todMult    = typeof getTODBonus  === 'function' ? getTODBonus().xpMult : 1;
  const skillMult  = typeof getSkillTreeXPBonus === 'function' ? (1 + getSkillTreeXPBonus(type || 'side')) : 1;
  const runeMult   = typeof getRuneBonus === 'function' ? (1 + getRuneBonus('all_xp')) : 1;
  const weaponMult   = 1 + getWeaponBonus('xpBonus');
  const mountAtkMult   = typeof getPetMountStat    === 'function' ? (1 + getPetMountStat('atk') / 100) : 1;
  const seasonalMult   = typeof getSeasonalXPMult  === 'function' ? getSeasonalXPMult() : 1;
  const dungeonXPMult = typeof getDungeonBonus==='function' ? getDungeonBonus('xp') : 1;
  const doctrineXPMult = 1 + getPrestigeDoctrineBonus('xp');
  const equipmentResonanceMult = typeof getEquipmentResonanceBonus === 'function' ? 1 + getEquipmentResonanceBonus('xp') : 1;
  const h = new Date().getHours();
  const nightRuneMult = (typeof getRuneBonus==='function' && (h >= 20 || h < 5)) ? (1 + getRuneBonus('night_xp')) : 1;
  let finalXP = Math.round(amount * classXPBonus(type || 'side') * xpMultiplier * todMult * skillMult * runeMult * weaponMult * mountAtkMult * seasonalMult * dungeonXPMult * doctrineXPMult * equipmentResonanceMult * nightRuneMult);

  if (typeof trackWeekXP === 'function') trackWeekXP(finalXP);
  const prevLevel = calcLevel(hero.xp_total || 0);

  const { data, error } = await db.rpc('grant_dungeon_currency', { p_source: type || 'client_misc', p_xp: finalXP });
  const r = Array.isArray(data) ? data[0] : data;
  if (error || !r) {
    toast('⚠️', 'No se pudo guardar tu progreso. Revisa la conexión e inténtalo de nuevo.');
    return;
  }
  hero.xp_total = r.xp_total;
  hero.level = r.level;
  const newLevel = r.level;
  deriveHero();
  try { localStorage.setItem('dungeon-cache-hero', JSON.stringify(hero)); } catch {}
  if (sourceEl) spawnParticle(`+${finalXP} XP`, sourceEl);

  if (newLevel > prevLevel) {
    const gainedPoints = newLevel - prevLevel;
    hero.attr_points  = (hero.attr_points  || 0) + gainedPoints;
    hero.skill_points = (hero.skill_points || 0) + gainedPoints;
    // level_history is JSONB — Supabase returns it as an array, not a string
    const hist = Array.isArray(hero.level_history)
      ? [...hero.level_history]
      : (() => { try { return JSON.parse(hero.level_history || '[]'); } catch { return []; } })();
    hist.push({ level: newLevel, date: new Date().toISOString().split('T')[0], xp_total: hero.xp_total });
    await saveHero({ attr_points: hero.attr_points, skill_points: hero.skill_points, level_history: hist });
    showLevelUp(newLevel);
    checkAchievements();
    if (typeof dungeonPush === 'function') dungeonPush('⭐ ¡Subiste de nivel!', `${hero.name} alcanzó el nivel ${newLevel}. El dungeon tiembla.`);
    if (webhookUrl) {
      fetch(webhookUrl, { method: 'POST', headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ hero: hero.name, newLevel, oldLevel: prevLevel, timestamp: new Date().toISOString() })
      }).catch(() => {});
    }
  }
  renderHeroUI();
}

/* STREAK */
async function checkDailyStreak() {
  if (!hero) return;
  const callRpc = typeof rpcWithRetry === 'function'
    ? () => rpcWithRetry('touch_dungeon_daily_streak', {}, { pendingKey:'daily-streak' })
    : () => db.rpc('touch_dungeon_daily_streak', {});
  const { data, error } = await callRpc();
  const state = Array.isArray(data) ? data[0] : data;
  if (error || !state) {
    console.error('touch_dungeon_daily_streak', error);
    return;
  }
  if (!state.changed) {
    Object.assign(hero, {
      streak: Number(state.streak || hero.streak || 0),
      longest_streak: Number(state.longest_streak || hero.longest_streak || 0),
      last_active_date: state.last_active_date || hero.last_active_date,
      hp: Number(state.hp || hero.hp || 100),
    });
    deriveHero();
    return;
  }

  Object.assign(hero, {
    streak: Number(state.streak || 1),
    longest_streak: Number(state.longest_streak || state.streak || 1),
    last_active_date: state.last_active_date,
    hp: Number(state.hp || hero.hp || 100),
    amulet: state.amulet_consumed ? false : hero.amulet,
  });
  renderHeroUI();
  if (state.amulet_consumed) {
    toast('🧿', '¡Amuleto de Protección absorbió el daño del día sin actividad!');
  } else if (Number(state.hp_lost || 0) > 0) {
    if (typeof spawnHPParticle === 'function') {
      const el = document.getElementById('heroHp');
      spawnHPParticle(-Number(state.hp_lost), el);
    }
    toast('💔', 'Perdiste HP por días sin actividad.');
  } else if (state.orco_forgiven) {
    toast('💪', '¡Resistencia Orca! La racha se mantiene.');
  }
  checkAchievements();
  if ((hero.streak || 0) > 1 && typeof damageBoss === 'function') {
    const dmg = Math.min((hero.streak || 0) * 2, 30);
    damageBoss(dmg);
    toast('🔥', `¡Racha ×${hero.streak}! El jefe recibe ${dmg} de daño.`);
  }

  // Track total active days for Titán secret class
  const _prog = getSecretProgress();
  _prog.total_active_days = (_prog.total_active_days || 0) + 1;
  if ((hero.hp || 0) <= 10) _prog.hp_zeros = (_prog.hp_zeros || 0) + 1;
  await saveSecretProgress(_prog);
  checkSecretClassUnlocks();
}

/* ── CLASES SECRETAS ─────────────────────────────────────── */
function getSecretProgress() {
  try { return JSON.parse(hero.secret_progress || '{}'); } catch { return {}; }
}

async function saveSecretProgress(prog) {
  hero.secret_progress = JSON.stringify(prog);
  await db.from('dungeon_heroes').update({ secret_progress: hero.secret_progress }).eq('id', hero.id);
}

async function checkSecretClassUnlocks() {
  if (!hero) return;
  const prog = getSecretProgress();
  const classes = (() => { try { return JSON.parse(hero.secret_classes || '[]'); } catch { return []; } })();

  const conds = {
    'crononauta':    (prog.midnight_total || 0) >= 100,
    'paladin':       (prog.health_total || 0) >= 50,
    'nigromante':    (prog.hp_zeros || 0) >= 3,
    'titan':         (prog.total_active_days || 0) >= 500,
    'druida':        (prog.midnight_streak || 0) >= 30,
    'estrella-caida':['crononauta','paladin','nigromante','titan','druida'].every(k => classes.includes(k)),
  };

  const newOnes = Object.entries(conds)
    .filter(([k, met]) => met && !classes.includes(k))
    .map(([k]) => k);
  if (!newOnes.length) return;

  const updated = [...classes, ...newOnes];
  hero.secret_classes = JSON.stringify(updated);
  await db.from('dungeon_heroes').update({ secret_classes: hero.secret_classes }).eq('id', hero.id);

  const defs = typeof SECRET_CLASS_DEFS !== 'undefined' ? SECRET_CLASS_DEFS : [];
  newOnes.forEach(k => {
    const d = defs.find(x => x.key === k);
    toast(d?.icon || '🔓', `¡Clase Secreta desbloqueada: ${d?.name || k}!`);
    if (typeof dungeonPush === 'function') dungeonPush('🔓 Clase Secreta', `${d?.name || k} desbloqueada. Ve a tu personaje para adoptarla.`);
    // Cada clase desbloqueada (excepto Estrella Caída) otorga 1 Polvo Estelar automático
    if (k !== 'estrella-caida' && typeof addInvItem === 'function') {
      setTimeout(() => addInvItem('secret_mat_estrella', 'secret_material', 1), 1500);
    }
  });
  if (typeof renderCharacterSheet === 'function') renderCharacterSheet();
}

/* addHP — helper global para modificar HP y rastrear mínimos */
async function addHP(amount) {
  if (!hero) return;
  const runeHpMax    = typeof getRuneBonus === 'function' ? getRuneBonus('hp_max') : 0;
  const masteryHpMult = 1 + (typeof getMasteryBonus === 'function' ? getMasteryBonus('vigor') : 0);
  const effMax        = Math.round(((hero.hp_max || 100) + runeHpMax) * masteryHpMult);
  let newHp = Math.max(0, Math.min((hero.hp || 0) + amount, effMax));

  // Bono de set Nigromante: revive automático 1×/semana al llegar a 0 HP
  if (newHp === 0 && typeof isSecretSetComplete === 'function' && isSecretSetComplete('nigromante')) {
    const _prog = getSecretProgress();
    const lastRevive = _prog.nigromante_revive_at ? new Date(_prog.nigromante_revive_at) : null;
    if (!lastRevive || Date.now() - lastRevive.getTime() > 7 * 86400000) {
      newHp = Math.round((hero.hp_max || 100) * 0.25);
      _prog.nigromante_revive_at = new Date().toISOString();
      await saveSecretProgress(_prog);
      if (typeof toast === 'function') toast('💀', '¡Set del Nigromante te revive con 25% HP!');
    }
  }

  await saveHero({ hp: newHp });
  renderHeroUI();
  if (amount < 0 && newHp <= 10) {
    const _prog = getSecretProgress();
    _prog.hp_zeros = (_prog.hp_zeros || 0) + 1;
    await saveSecretProgress(_prog);
    checkSecretClassUnlocks();
  }
  // Nigromante: al llegar exactamente a 0 HP, garantiza 1 Hueso del Renacer
  if (amount < 0 && newHp === 0) {
    const _cls = (() => { try { return JSON.parse(hero.secret_classes || '[]'); } catch { return []; } })();
    if (_cls.includes('nigromante') && typeof addInvItem === 'function') {
      setTimeout(async () => {
        await addInvItem('secret_mat_nigromante', 'secret_material', 1);
        if (typeof toast === 'function') toast('🦴', '¡Hueso del Renacer obtenido al caer!');
      }, 600);
    }
  }
}
