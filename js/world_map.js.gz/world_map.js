/* ── MAPA DEL MUNDO INTERACTIVO ─────────────────────────── */

// Posiciones (% del ancho/alto del contenedor) para cada zona.
// Ajustables según el arte final del mapa.
const ZONE_MAP_POSITIONS = {
  ciudadela: { x: 43, y: 22 },
  campo:     { x: 72, y: 30 },
  torre:     { x: 12, y: 12 },
  fortaleza: { x: 75, y: 70 },
  jardin:    { x: 17, y: 68 },
  cripta:    { x: 43, y: 80 },
};

let _worldMapEl = null;

function renderWorldMap() {
  const el = document.getElementById('worldMapView');
  if (!el) return;
  _worldMapEl = el;

  const zoneXPs = typeof calcZoneXP === 'function' ? calcZoneXP() : {};

  const hotspots = ZONES.map(z => {
    const pos  = ZONE_MAP_POSITIONS[z.id] || { x: 50, y: 50 };
    const xp   = zoneXPs[z.id] || 0;
    const info = typeof _zoneRankInfo === 'function' ? _zoneRankInfo(z, xp) : { rank: 0 };
    const rankNames = ['Forastero','Conocido','Aliado','Campeón','Leyenda'];
    const rankName  = rankNames[info.rank] || 'Forastero';
    const rankColor = ['var(--text3)','#60a5fa','#a78bfa','#fb923c','#facc15'][info.rank] || 'var(--text3)';
    return `<button class="wm-hotspot" data-zone="${z.id}"
        style="left:${pos.x}%;top:${pos.y}%;--z-clr:${z.color}"
        onclick="_wmOpenZone('${z.id}')"
        title="${z.name} — ${rankName}">
      <div class="wm-hs-icon">
        <img src="images/map_${z.id}.webp" class="wm-hs-img" alt="${z.name}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
        <span style="display:none">${z.icon}</span>
      </div>
      <div class="wm-hs-label" style="color:${rankColor}">${z.name}</div>
    </button>`;
  }).join('');

  const mapSrc = 'images/mapa_mundo.webp';

  el.innerHTML = `
    <div class="wm-wrap">
      <div class="wm-container" id="wmContainer">
        <img src="${mapSrc}" class="wm-img" alt="Mapa del Mundo"
             onerror="this.style.display='none';document.getElementById('wmBgFallback').style.display='block'">
        <div class="wm-bg-fallback" id="wmBgFallback" style="display:none"></div>
        ${hotspots}
      </div>
      <div class="wm-legend">
        ${ZONES.map(z => {
          const xp  = zoneXPs[z.id] || 0;
          const inf = typeof _zoneRankInfo === 'function' ? _zoneRankInfo(z, xp) : { rank: 0 };
          const rn  = ['Forastero','Conocido','Aliado','Campeón','Leyenda'][inf.rank] || 'Forastero';
          const rc  = ['var(--text3)','#60a5fa','#a78bfa','#fb923c','#facc15'][inf.rank] || 'var(--text3)';
          return `<div class="wm-legend-row">
            <span class="wm-legend-icon" style="--z-clr:${z.color}">
              <img src="images/map_${z.id}.webp" class="wm-legend-img" alt="${z.name}"
                   onerror="this.style.display='none';this.nextElementSibling.style.display='inline'">
              <span style="display:none">${z.icon}</span>
            </span>
            <span class="wm-legend-name">${z.name}</span>
            <span class="wm-legend-rank" style="color:${rc}">${rn}</span>
            <span class="wm-legend-xp">${xp} XP</span>
          </div>`;
        }).join('')}
      </div>
    </div>
    <div class="wm-detail-panel" id="wmDetailPanel" style="display:none"></div>`;
}

/* ── PUNTOS DE ACCIÓN DEL MAPA (3/día, gasto 1 AP → +15% XP 2h en zona) ── */
function _wmGetAP() {
  const today = new Date().toISOString().split('T')[0];
  try {
    const d = JSON.parse(localStorage.getItem('dungeon-map-ap') || '{}');
    return d.date === today ? (d.ap ?? 3) : 3;
  } catch { return 3; }
}
function _wmSetAP(n) {
  const today = new Date().toISOString().split('T')[0];
  localStorage.setItem('dungeon-map-ap', JSON.stringify({ date: today, ap: Math.max(0, n) }));
}
function wmSpendAP(zoneId, route = 'xp') {
  const ap = _wmGetAP();
  if (ap <= 0) { toast('⚡', 'Sin Puntos de Acción. Se renuevan mañana (3/día).'); return; }
  _wmSetAP(ap - 1);
  const expires = Date.now() + 2 * 60 * 60 * 1000;
  localStorage.setItem('dungeon-map-bonus-' + zoneId, JSON.stringify({ expires, route }));
  const z = (typeof ZONES !== 'undefined' ? ZONES : []).find(z => z.id === zoneId);
  const routeText = { xp:'+15% XP', gold:'+20% oro', recovery:'+15 HP' }[route] || '+15% XP';
  toast('Mapa', `${z?.name || 'Zona'} activada: ${routeText} durante 2h (${ap - 1} AP restantes).`);
  _wmOpenZone(zoneId);
}

function _wmOpenZone(zoneId) {
  const z     = ZONES.find(z => z.id === zoneId);
  const panel = document.getElementById('wmDetailPanel');
  if (!z || !panel) return;

  const zoneXPs = typeof calcZoneXP === 'function' ? calcZoneXP() : {};
  const xp      = zoneXPs[zoneId] || 0;
  const inf     = typeof _zoneRankInfo === 'function' ? _zoneRankInfo(z, xp) : { rank: 0, next: 0, bonus: 0 };
  const rankNames  = ['Forastero','Conocido','Aliado','Campeón','Leyenda'];
  const rankColors = ['var(--text3)','#60a5fa','#a78bfa','#fb923c','#facc15'];
  const rName  = rankNames[inf.rank]  || 'Forastero';
  const rColor = rankColors[inf.rank] || 'var(--text3)';
  const pct    = inf.next > 0 ? Math.min(100, Math.round((xp / inf.next) * 100)) : 100;
  const bonusTxt = inf.bonus > 0 ? `+${Math.round(inf.bonus * 100)}% XP` : 'Sin bonus aún';

  // AP system
  const ap = _wmGetAP();
  let mapBonus = null;
  try { mapBonus = JSON.parse(localStorage.getItem('dungeon-map-bonus-' + zoneId) || 'null'); } catch {}
  const apActive = mapBonus && mapBonus.expires > Date.now();
  const apMinsLeft = apActive ? Math.ceil((mapBonus.expires - Date.now()) / 60000) : 0;
  const apSection = apActive
    ? `<div class="wm-ap-active">⚡ +15% XP activo — ${apMinsLeft} min restantes</div>`
    : `<button class="wm-ap-btn" onclick="wmSpendAP('${zoneId}')" ${ap <= 0 ? 'disabled' : ''}>
         🗺️ Activar +15% XP (2h) · Cuesta 1 AP
       </button>
       <div class="wm-ap-count">${ap}/3 AP disponibles hoy</div>`;

  // Highlight active hotspot
  document.querySelectorAll('.wm-hotspot').forEach(b => b.classList.toggle('wm-hs-active', b.dataset.zone === zoneId));

  panel.style.display = '';
  panel.innerHTML = `
    <div class="wm-detail-inner" style="--z-clr:${z.color}">
      <button class="wm-detail-close" onclick="document.getElementById('wmDetailPanel').style.display='none';document.querySelectorAll('.wm-hotspot').forEach(b=>b.classList.remove('wm-hs-active'))">✕</button>
      <div class="wm-detail-icon">
        <img src="images/map_${z.id}.webp" class="wm-detail-img" alt="${z.name}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
        <span style="display:none">${z.icon}</span>
      </div>
      <div class="wm-detail-name">${z.name}</div>
      <div class="wm-detail-desc">${z.desc}</div>
      <div class="wm-detail-rank" style="color:${rColor}">${rName}</div>
      <div class="wm-detail-xp">${xp} / ${inf.next || '∞'} XP</div>
      <div class="wm-bar-bg"><div class="wm-bar-fill" style="width:${pct}%;background:${z.color}"></div></div>
      <div class="wm-detail-bonus">${bonusTxt}</div>
      ${apSection}
    </div>`;

  if (apActive) {
    const label = { xp: '+15% XP', gold: '+20% oro', recovery: '+15 HP' }[mapBonus.route || 'xp'];
    const activeEl = panel.querySelector('.wm-ap-active');
    if (activeEl) activeEl.textContent = `⚡ Expedición activa: ${label} · ${apMinsLeft} min restantes`;
  }

  if (!apActive && ap > 0) {
    const count = panel.querySelector('.wm-ap-count');
    count?.insertAdjacentHTML('beforebegin', `
      <div class="wm-route-title">Elegir enfoque de expedición</div>
      <div class="wm-route-grid">
        <button class="wm-ap-btn" onclick="wmSpendAP('${zoneId}','xp')">📜 Saber<small>+15% XP</small></button>
        <button class="wm-ap-btn" onclick="wmSpendAP('${zoneId}','gold')">💰 Tesoro<small>+20% oro</small></button>
        <button class="wm-ap-btn" onclick="wmSpendAP('${zoneId}','recovery')">🛡️ Refugio<small>+15 HP</small></button>
      </div>`);
    const original = panel.querySelector('.wm-ap-btn');
    if (original) original.style.display = 'none';
  }
}
