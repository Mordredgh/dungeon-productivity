'use strict';

let weapons = [];

async function loadWeapons() {
  if (!hero) return;
  const { data } = await db.from('dungeon_weapons').select('*')
    .eq('hero_id', hero.id).order('obtained_at', { ascending: false });
  weapons = data || [];
}

function getWeaponBonus(stat) {
  return weapons.filter(w => w.is_equipped).reduce((sum, w) => {
    const ad = typeof ARMOR_DEFS !== 'undefined' ? ARMOR_DEFS.find(d => d.key === w.weapon_key) : null;
    if (ad) return ad.statKey === stat ? sum + (ad.statBase[w.tier] || 0) : sum;
    return sum + (WEAPON_TIERS[w.tier]?.[stat] || 0);
  }, 0);
}

async function addWeapon(weaponKey, tier, readyAt) {
  const def     = WEAPON_DEFS.find(d => d.key === weaponKey);
  const tierDef = WEAPON_TIERS[tier];
  if (!def || !tierDef) return null;
  const name = `${def.name} ${tierDef.label}`;
  const { data } = await db.from('dungeon_weapons').insert({
    hero_id: hero.id, weapon_key: weaponKey, tier, name,
    is_equipped: false, obtained_at: new Date().toISOString(),
    ready_at: readyAt || null
  }).select().single();
  if (data) weapons.push(data);
  return data;
}

function isForging(w) { return w.ready_at && new Date(w.ready_at) > new Date(); }

async function equipWeapon(id) {
  const w = weapons.find(x => x.id === id);
  if (!w) return;
  if (isForging(w)) { toast('⏳', 'Esta arma todavía se está forjando.'); return; }
  const def = WEAPON_DEFS.find(d => d.key === w.weapon_key);
  const slot = def?.slot || 'main_hand';
  const current = weapons.find(x => x.is_equipped && x.slot === slot && x.id !== id);
  if (current) {
    await db.from('dungeon_weapons').update({ is_equipped: false, slot: null }).eq('id', current.id);
    current.is_equipped = false; current.slot = null;
  }
  await db.from('dungeon_weapons').update({ is_equipped: true, slot }).eq('id', id);
  w.is_equipped = true; w.slot = slot;
  toast('⚔️', `${w.name} equipada.`);
  renderInventory(); renderSmithy();
}

async function unequipWeapon(id) {
  const w = weapons.find(x => x.id === id);
  if (!w) return;
  await db.from('dungeon_weapons').update({ is_equipped: false, slot: null }).eq('id', id);
  w.is_equipped = false; w.slot = null;
  toast('🎒', `${w.name} desequipada.`);
  renderInventory(); renderSmithy();
}

/* Un set de armadura completo (casco, pecho, grebas y botas) del mismo rango
   forma una resonancia. Guantes y armas conservan su papel individual: no
   contaminan la decisión del set principal. */
const EQUIPMENT_RESONANCES = {
  raro:       { name:'Resonancia Azul', effect:'xp', value:.03, label:'+3% XP' },
  epico:      { name:'Resonancia Violeta', effect:'gold', value:.05, label:'+5% oro' },
  legendario: { name:'Resonancia Dorada', effect:'boss_dmg', value:.05, label:'+5% daño a jefes' },
  mitico:     { name:'Resonancia Mítica', effect:'all', value:.07, label:'+7% XP, oro y daño a jefes' },
};
function getEquipmentResonance() {
  const setSlots = ['head', 'body', 'legs', 'feet'];
  const equipped = weapons.filter(item => item.is_equipped && !isForging(item));
  const setByTier = Object.keys(EQUIPMENT_RESONANCES).map(tier => {
    const pieces = new Set(equipped.filter(item => item.tier === tier)
      .map(item => WEAPON_DEFS.find(def => def.key === item.weapon_key)?.slot)
      .filter(slot => setSlots.includes(slot)));
    return { tier, pieces };
  });
  const active = setByTier.find(item => item.pieces.size === setSlots.length);
  return active ? { tier:active.tier, ...EQUIPMENT_RESONANCES[active.tier], count:setSlots.length } : null;
}
function getEquipmentResonanceBonus(effect) {
  const resonance = getEquipmentResonance();
  return resonance && (resonance.effect === effect || resonance.effect === 'all') ? resonance.value : 0;
}

async function salvageWeapon(id) {
  const weapon = weapons.find(item => item.id === id);
  if (!weapon || weapon.is_equipped || isForging(weapon)) return;
  const fragments = { comun:1, raro:2, epico:4, legendario:7, mitico:12 }[weapon.tier] || 1;
  if (!confirm(`Desmantelar ${weapon.name}? Recuperarás ${fragments} fragmentos de runa.`)) return;
  const { error } = await db.from('dungeon_weapons').delete().eq('id', weapon.id).eq('hero_id', hero.id);
  if (error) { toast('Error', 'No se pudo desmantelar la pieza.'); return; }
  weapons = weapons.filter(item => item.id !== weapon.id);
  if (typeof addInvItem === 'function') await addInvItem('rune_fragment', 'rune_fragment', fragments);
  toast('♢', `${weapon.name} se convirtió en ${fragments} fragmentos de runa.`);
  renderInventory(); renderSmithy();
}

async function craftWeapon(weaponKey, targetTier) {
  const recipe = CRAFT_RECIPES[targetTier];
  if (!recipe) return;
  const { data, error } = await db.rpc('forge_dungeon_weapon', {
    p_weapon_key: weaponKey,
    p_target_tier: targetTier
  });
  if (error) { toast('⚒️', error.message || 'No se pudo forjar.'); return; }
  const newW = Array.isArray(data) ? data[0] : data;
  await loadWeapons();
  if (newW) toast('⚒️', `¡${newW.name} forjada!`);
  renderInventory(); renderSmithy();
}

/* ── INVENTORY VIEW ─────────────────────────────────────── */
function renderInventoryLegacy() {
  const el = document.getElementById('inventoryView');
  if (!el) return;

  const gold       = typeof getGold === 'function' ? getGold() : 0;
  const inv        = typeof inventory !== 'undefined' ? inventory : [];
  const fragments  = inv.filter(i => i.item_type === 'spell_fragment' && i.quantity > 0);
  const potions    = inv.filter(i => i.item_type === 'pet_potion'    && i.quantity > 0);
  const eggs       = inv.filter(i => i.item_type === 'pet_egg'       && i.quantity > 0);
  const foods      = inv.filter(i => i.item_type === 'pet_food'      && i.quantity > 0);
  const consumables= inv.filter(i => !['spell_fragment','pet_potion','pet_egg','pet_food'].includes(i.item_type) && i.quantity > 0);
  const equipped   = weapons.filter(w => w.is_equipped);
  const bag        = weapons.filter(w => !w.is_equipped);

  const forgingLabel = w => {
    const ms = new Date(w.ready_at) - new Date();
    const h  = Math.ceil(ms / 3600000);
    return h > 24 ? `⏳ Listo en ${Math.ceil(h / 24)}d` : `⏳ Listo en ${h}h`;
  };

  const weaponCard = w => {
    const def  = WEAPON_DEFS.find(d => d.key === w.weapon_key) || { icon:'⚔️' };
    const tier = WEAPON_TIERS[w.tier] || { color:'#9ca3af', label:w.tier };
    const img  = 'images/arma_' + w.weapon_key + '_' + w.tier + '.webp';
    const forging = isForging(w);
    const stats = [
      tier.xpBonus  ? `✨ +${Math.round(tier.xpBonus*100)}% XP`   : '',
      tier.goldBonus? `🪙 +${Math.round(tier.goldBonus*100)}% Oro` : '',
    ].filter(Boolean).join(' · ');
    const glow = !forging && (w.tier === 'legendario' || w.tier === 'mitico') ? 'anim-pulse-glow' : '';
    return `
      <div class="inv-weapon-card ${w.is_equipped ? 'inv-weapon-equipped' : ''} ${forging ? 'inv-weapon-forging' : ''} ${glow}" style="--wc:${tier.color}">
        <img src="${img}" class="inv-weapon-img" alt="${escHtml(w.name)}" loading="lazy" decoding="async" style="${forging ? 'opacity:.4;filter:grayscale(1)' : ''}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="inv-weapon-emoji" style="display:none">${def.icon}</div>
        <div class="inv-weapon-info">
          <div class="inv-weapon-name">${escHtml(w.name)}</div>
          <span class="inv-tier-badge" style="color:${tier.color};border-color:${tier.color}40;background:${tier.color}18">${tier.label}</span>
          ${forging ? `<div class="inv-weapon-stats" style="color:var(--gold)">${forgingLabel(w)}</div>` : stats ? `<div class="inv-weapon-stats">${stats}</div>` : ''}
          ${w.slot ? `<div class="inv-weapon-slot">${w.slot==='main_hand'?'⚔️ Mano principal':'🛡️ Mano secundaria'}</div>` : ''}
          ${(() => {
            const maxSlots = (typeof RUNE_SOCKET_COUNT !== 'undefined' ? RUNE_SOCKET_COUNT[w.tier] : 0) || 0;
            if (!maxSlots) return '<div class="inv-rune-row" style="color:var(--text3);font-size:10px">Sin ranuras de runa</div>';
            const filled = (() => { try { return w.rune_slots ? JSON.parse(w.rune_slots) : []; } catch(e) { return []; } })();
            const runeArr = typeof runes !== 'undefined' ? runes : [];
            const slots = Array.from({length: maxSlots}, (_, i) => {
              const rid = filled[i];
              const r   = rid ? runeArr.find(x => x.id === rid) : null;
              const d   = r && typeof RUNE_DEFS !== 'undefined' ? RUNE_DEFS[r.rune_type] : null;
              return `<span class="inv-rune-slot${d?' inv-rune-filled':''}" style="${d?`--rc:${d.color}`:'--rc:#4b5563'}" title="${d?d.name+' · '+d.desc:'Ranura vacía — engasta en Runas'}">${d?d.icon:'◇'}</span>`;
            }).join('');
            return `<div class="inv-rune-row">💎 ${slots}</div>`;
          })()}
        </div>
        <button class="inv-eq-btn ${w.is_equipped?'inv-eq-active':''}" ${forging ? 'disabled' : ''}
          onclick="${w.is_equipped?`unequipWeapon('${w.id}')`:`equipWeapon('${w.id}')`}">
          ${forging ? '⏳' : w.is_equipped?'Desequipar':'Equipar'}
        </button>
      </div>`;
  };

  const itemRow = (i, labelFn) => {
    const _iKey = i.item_key
      .replace(/^pet_food_/,    'pet_alimento_')
      .replace(/^pet_potion_/,  'pet_pocion_');
    const img = CDN + 'dungeon/' + _iKey + '.png';
    return `
      <div class="inv-item-row">
        <img src="${img}" class="inv-item-img" alt="" loading="lazy" decoding="async"
             onerror="this.style.display='none';this.nextElementSibling.style.display='inline'">
        <span style="display:none;font-size:18px">📦</span>
        <span class="inv-item-name">${escHtml(labelFn(i))}</span>
        <span class="inv-item-qty">×${i.quantity}</span>
      </div>`;
  };

  const potLabel  = i => { const p = (typeof PET_DEFS!=='undefined'?PET_DEFS:[]).find(p=>p.key===i.item_key.replace('pet_potion_','')); return p?`Poción de ${p.name}`:i.item_key; };
  const eggLabel  = i => { const p = (typeof PET_DEFS!=='undefined'?PET_DEFS:[]).find(p=>p.key===i.item_key.replace('pet_egg_','')); return p?`Huevo de ${p.name}`:i.item_key; };

  const section = (title, content) => `
    <div class="inv-section">
      <div class="inv-section-title">${title}</div>
      ${content}
    </div>`;

  const empty = `<div class="inv-empty">Vacío</div>`;

  /* RPG grid helpers for spells/potions */
  const COLS = 5;
  const spellOff = typeof _SPELL_OFFENSIVE !== 'undefined' ? _SPELL_OFFENSIVE : new Set();
  const spellsOff = fragments.filter(r => spellOff.has(r.item_key.slice(6)));
  const spellsDef = fragments.filter(r => !spellOff.has(r.item_key.slice(6)));

  const rpgSlot = (item, catClass) => {
    const meta = typeof _invItemMeta === 'function' ? _invItemMeta(item.item_key) : { name: item.item_key, icon: '🎁', color: '#94a3b8' };
    const shortName = meta.name.split(' ').slice(-2).join(' ');
    const badge = catClass === 'offense'
      ? '<span class="inv-slot-badge inv-slot-badge--atk">ATK</span>'
      : catClass === 'defense'
        ? '<span class="inv-slot-badge inv-slot-badge--def">DEF</span>'
        : '';
    const imgSrc = item.item_key.startsWith('spell_')
      ? `/images/${item.item_key}.webp`
      : item.item_key.startsWith('pet_egg_')
        ? `/images/pet_egg_${item.item_key.slice(8)}.webp`
        : item.item_key.startsWith('pet_food_')
          ? `${CDN}dungeon/${item.item_key.replace('pet_food_', 'pet_alimento_')}.png`
          : item.item_key.startsWith('pet_potion_')
            ? `${CDN}dungeon/${item.item_key.replace('pet_potion_', 'pet_pocion_')}.png`
            : `${CDN}dungeon/${item.item_key}.png`;
    return `<button class="inv-slot" onclick="showInvItemDetail('${escHtml(item.item_key)}')"
        title="${escHtml(meta.name)}" style="--inv-color:${meta.color}">
      ${badge}
      <div class="inv-slot-inner">
        <img src="${imgSrc}" class="inv-slot-img" alt=""
             onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="inv-slot-emoji" style="display:none">${meta.icon}</div>
        <div class="inv-slot-qty">×${item.quantity}</div>
      </div>
      <div class="inv-slot-name">${escHtml(shortName)}</div>
    </button>`;
  };

  const rpgCat = (title, items, catClass, headerMod) => {
    if (!items.length) return '';
    const padded = [...items];
    while (padded.length % COLS !== 0) padded.push(null);
    const slots = padded.map(it => it ? rpgSlot(it, catClass) : '<div class="inv-slot inv-empty"></div>').join('');
    return `<div class="inv-cat-header inv-cat-header--${headerMod}">${title}</div>
            <div class="inv-grid">${slots}</div>`;
  };

  const eggSection  = rpgCat('🥚 Huevos',       eggs,  'egg',  'egg');
  const foodSection = rpgCat('🍖 Alimento',      foods, 'food', 'food');

  el.innerHTML = `
    <div class="inv-gold-banner">
      <span style="font-size:28px">🪙</span>
      <div>
        <div class="inv-gold-amt" id="invGoldAmt">${gold.toLocaleString()}</div>
        <div class="inv-gold-lbl">Oro disponible</div>
      </div>
      <button class="btn btn-primary" style="margin-left:auto;padding:7px 18px;font-size:12px"
        onclick="switchView('shop')">🏪 Ir a la Tienda</button>
    </div>

    ${section('⚔️ Armas Equipadas',
      equipped.length ? `<div class="inv-weapons-list">${equipped.map(weaponCard).join('')}</div>` : empty)}

    ${bag.length ? section('🎒 Mochila — Armas',
      `<div class="inv-weapons-list">${bag.map(weaponCard).join('')}</div>
       <button class="btn btn-ghost" style="font-size:12px;margin-top:8px" onclick="switchView('smithy')">⚒️ Ir al Herrero</button>`) : ''}

    ${rpgCat('⚔️ Hechizos Ofensivos', spellsOff, 'offense', 'offense')}
    ${rpgCat('🛡️ Hechizos Defensivos', spellsDef, 'defense', 'defense')}
    ${rpgCat('🧪 Pociones de Mascota', potions, 'potion', 'potion')}
    ${eggSection}
    ${foodSection}
    ${consumables.length ? rpgCat('⚗️ Consumibles', consumables, 'misc', 'misc') : ''}

    ${!weapons.length && !inv.length ? `<div class="inv-empty" style="margin-top:40px;font-size:15px">
      <div style="font-size:48px;margin-bottom:12px">🎒</div>
      Tu mochila está vacía.<br>
      <button class="btn btn-primary" style="margin-top:12px" onclick="switchView('shop')">🏪 Ir a la Tienda</button>
    </div>` : ''}
  `;
}

/* ── SMITHY VIEW ─────────────────────────────────────────── */
/* Bóveda unificada: sustituye las dos vistas heredadas de inventario. */
let _vaultActiveTab = 'all';

function setVaultTab(tab) {
  _vaultActiveTab = tab;
  renderInventory();
}

function _vaultItemGroup(item) {
  const key = item.item_key || '';
  if (key.startsWith('spell_') || key.startsWith('rune_')) return 'magic';
  if (key.startsWith('pet_egg_') || key.startsWith('pet_potion_') || key.startsWith('pet_food_')) return 'pets';
  return 'materials';
}

function _vaultItemCard(item) {
  const meta = typeof _invItemMeta === 'function' ? _invItemMeta(item.item_key) : { name:item.item_key, icon:'🎁', color:'#a78bfa', desc:'' };
  const key = item.item_key;
  const imageKey = key.replace(/^pet_food_/, 'pet_alimento_').replace(/^pet_potion_/, 'pet_pocion_');
  const isSpell = key.startsWith('spell_');
  const itemType = isSpell ? 'Hechizo' : key.startsWith('rune_') ? 'Runa' : _vaultItemGroup(item) === 'pets' ? 'Mascota' : 'Material';
  return `
    <button class="vault-item-card" style="--vault-item:${meta.color || '#a78bfa'}" onclick="showInvItemDetail('${escHtml(key)}')" title="${escHtml(meta.name)}">
      <span class="vault-item-type">${itemType}</span>
      <img src="${CDN}dungeon/${imageKey}.png" class="vault-item-img" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
      <span class="vault-item-fallback" style="display:none">${meta.icon || '🎁'}</span>
      <span class="vault-item-qty">×${item.quantity}</span>
      <span class="vault-item-name">${escHtml(meta.name)}</span>
      <span class="vault-item-hint">${isSpell ? 'Conjurar' : meta.desc || 'Ver detalle'}</span>
    </button>`;
}

function _vaultEquipmentCard(weapon) {
  const def = WEAPON_DEFS.find(d => d.key === weapon.weapon_key) || { icon:'⚔️', slot:'main_hand' };
  const tier = WEAPON_TIERS[weapon.tier] || { label:weapon.tier, color:'#94a3b8' };
  const forging = isForging(weapon);
  const sockets = (() => { try { return weapon.rune_slots ? JSON.parse(weapon.rune_slots) : []; } catch { return []; } })();
  const maxSockets = typeof RUNE_SOCKET_COUNT !== 'undefined' ? (RUNE_SOCKET_COUNT[weapon.tier] || 0) : 0;
  const effect = [tier.xpBonus ? `+${Math.round(tier.xpBonus * 100)}% XP` : '', tier.goldBonus ? `+${Math.round(tier.goldBonus * 100)}% oro` : ''].filter(Boolean).join(' · ') || 'Sin bonificación base';
  const slotLabel = { main_hand:'Mano principal', off_hand:'Mano secundaria', body:'Pecho', head:'Casco', feet:'Botas', hands:'Guantes', legs:'Grebas' }[def.slot] || def.slot;
  return `
    <article class="vault-gear-card ${weapon.is_equipped ? 'is-equipped' : ''} ${forging ? 'is-forging' : ''}" style="--vault-tier:${tier.color}">
      <div class="vault-gear-art"><img src="images/arma_${weapon.weapon_key}_${weapon.tier}.webp" alt="" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span style="display:none">${def.icon}</span></div>
      <div class="vault-gear-info">
        <div class="vault-gear-top"><span class="vault-gear-name">${escHtml(weapon.name)}</span><span class="vault-tier">${tier.label}</span></div>
        <div class="vault-gear-meta">${weapon.is_equipped ? 'Equipado · ' : ''}${slotLabel}</div>
        <div class="vault-gear-effect">${forging ? '⏳ En forja' : effect}</div>
        <div class="vault-sockets">${Array.from({length:maxSockets}, (_, index) => {
          const rune = runes?.find(r => r.id === sockets[index]);
          const rDef = rune && RUNE_DEFS?.[rune.rune_type];
          return `<span class="${rDef ? 'filled' : ''}" style="--rune:${rDef?.color || '#40344d'}">${rDef?.icon || '◇'}</span>`;
        }).join('') || '<em>Sin ranuras</em>'}</div>
      </div>
      <div class="vault-gear-actions"><button class="vault-gear-action" ${forging ? 'disabled' : ''} onclick="${weapon.is_equipped ? `unequipWeapon('${weapon.id}')` : `equipWeapon('${weapon.id}')`}">${forging ? 'Forjando' : weapon.is_equipped ? 'Quitar' : 'Equipar'}</button>${!weapon.is_equipped && !forging ? `<button class="vault-gear-salvage" onclick="salvageWeapon('${weapon.id}')" title="Desmantelar">♢</button>` : ''}</div>
    </article>`;
}

function renderInventory() {
  const el = document.getElementById('inventoryView');
  if (!el) return;
  const inv = (typeof inventory !== 'undefined' ? inventory : []).filter(item => item.quantity > 0);
  const equipped = weapons.filter(weapon => weapon.is_equipped);
  const bag = weapons.filter(weapon => !weapon.is_equipped);
  const tabItems = _vaultActiveTab === 'all' ? inv : inv.filter(item => _vaultItemGroup(item) === _vaultActiveTab);
  const showEquipment = _vaultActiveTab === 'all' || _vaultActiveTab === 'equipment';
  const showItems = _vaultActiveTab !== 'equipment';
  const groupCount = group => inv.filter(item => _vaultItemGroup(item) === group).length;
  const resonance = getEquipmentResonance();
  const tab = (id, icon, label, count) => `<button class="vault-tab ${_vaultActiveTab === id ? 'active' : ''}" onclick="setVaultTab('${id}')"><span>${icon}</span>${label}<b>${count}</b></button>`;

  el.innerHTML = `
    <section class="vault-shell">
      <header class="vault-header"><div><p class="vault-kicker">Bóveda del aventurero</p><h3>Inventario Arcano</h3><span>${equipped.length}/7 piezas equipadas · ${inv.length} tipos de objeto</span>${resonance ? `<div class="vault-resonance" style="--res:${WEAPON_TIERS[resonance.tier]?.color || '#c084fc'}"><b>${resonance.name}</b><span>Set de casco, pecho, grebas y botas · ${resonance.label}</span></div>` : '<div class="vault-resonance is-dormant"><b>Resonancia inactiva</b><span>Equipa casco, pecho, grebas y botas del mismo rango.</span></div>'}</div><div class="vault-gold"><span>🪙</span><strong>${(typeof getGold === 'function' ? getGold() : 0).toLocaleString()}</strong><small>oro</small></div></header>
      <nav class="vault-tabs" aria-label="Categorías de inventario">${tab('all','✦','Todo',inv.length + weapons.length)}${tab('equipment','⚔️','Equipo',weapons.length)}${tab('magic','🔮','Magia',groupCount('magic'))}${tab('pets','🐾','Mascotas',groupCount('pets'))}${tab('materials','◇','Materiales',groupCount('materials'))}</nav>
      ${showEquipment ? `<section class="vault-section"><div class="vault-section-head"><div><span>⚔️</span><h4>${_vaultActiveTab === 'all' ? 'Equipo activo' : 'Arsenal'}</h4></div><button class="vault-link" onclick="switchView('smithy')">Ir al Herrero →</button></div><div class="vault-gear-grid">${(equipped.length ? equipped : bag).map(_vaultEquipmentCard).join('') || '<div class="vault-empty">No tienes equipo todavía. La tienda del gremio tiene piezas comunes para iniciar.</div>'}</div>${_vaultActiveTab === 'all' && bag.length ? `<details class="vault-bag"><summary>Ver mochila de equipo <b>${bag.length}</b></summary><div class="vault-gear-grid">${bag.map(_vaultEquipmentCard).join('')}</div></details>` : ''}</section>` : ''}
      ${showItems ? `<section class="vault-section"><div class="vault-section-head"><div><span>✦</span><h4>${_vaultActiveTab === 'all' ? 'Objetos y recursos' : _vaultActiveTab === 'magic' ? 'Grimorio y runas' : _vaultActiveTab === 'pets' ? 'Suministros de mascotas' : 'Materiales'}</h4></div><button class="vault-link" onclick="switchView('shop')">Visitar tienda →</button></div>${tabItems.length ? `<div class="vault-item-grid">${tabItems.map(_vaultItemCard).join('')}</div>` : '<div class="vault-empty">Nada en esta categoría. Completa misiones, derrota jefes o visita la tienda.</div>'}</section>` : ''}
    </section>`;
}

function renderSmithy() {
  const el = document.getElementById('smithyView');
  if (!el) return;

  const byKeyTier = {};
  weapons.filter(w => !w.is_equipped && !isForging(w)).forEach(w => {
    const k = w.weapon_key + '|' + w.tier;
    byKeyTier[k] = (byKeyTier[k] || 0) + 1;
  });

  const tierOrder = ['raro','epico','legendario','mitico'];

  const armorKeys = typeof ARMOR_DEFS !== 'undefined' ? ARMOR_DEFS.map(d => d.key) : [];
  const weaponOnlyDefs = WEAPON_DEFS.filter(d => !armorKeys.includes(d.key));
  const armorDefs = WEAPON_DEFS.filter(d => armorKeys.includes(d.key));

  const buildRecipeRow = def => {
    let out = '';
    const ad = typeof ARMOR_DEFS !== 'undefined' ? ARMOR_DEFS.find(d => d.key === def.key) : null;
    tierOrder.forEach(targetTier => {
      const recipe  = CRAFT_RECIPES[targetTier];
      if (!recipe) return;
      const have    = byKeyTier[def.key + '|' + recipe.from] || 0;
      const canCraft= have >= recipe.count;
      const srcT    = WEAPON_TIERS[recipe.from];
      const dstT    = WEAPON_TIERS[targetTier];
      const img     = 'images/arma_' + def.key + '_' + targetTier + '.webp';
      let stats = '';
      if (ad) {
        const val = ad.statBase[targetTier] || 0;
        stats = ad.statKey === 'hpMax'
          ? `❤️ +${val} HP máx`
          : `${ad.statKey === 'xpBonus' ? '✨' : '🪙'} +${Math.round(val*100)}% ${ad.statKey === 'xpBonus' ? 'XP' : 'Oro'}`;
      } else {
        stats = [
          dstT.xpBonus  ? `✨ +${Math.round(dstT.xpBonus*100)}% XP`   : '',
          dstT.goldBonus? `🪙 +${Math.round(dstT.goldBonus*100)}% Oro` : '',
          dstT.hpMax    ? `❤️ +${dstT.hpMax} HP máx`                   : '',
        ].filter(Boolean).join(' · ');
      }
      const glow = (canCraft && (targetTier === 'legendario' || targetTier === 'mitico')) ? 'anim-pulse-glow' : '';
      out += `
        <div class="smithy-recipe ${canCraft?'smithy-ready':'smithy-locked'}">
          <img src="${img}" class="smithy-img ${glow}" style="--wc:${dstT.color}" alt=""
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
          <div class="smithy-emoji" style="display:none">${def.icon}</div>
          <div class="smithy-info">
            <div class="smithy-name">${def.name}
              <span class="inv-tier-badge" style="color:${dstT.color};border-color:${dstT.color}40;background:${dstT.color}18">${dstT.label}</span>
            </div>
            <div class="smithy-req">
              <span style="color:${srcT.color}">${recipe.count}× ${def.name} ${srcT.label}</span>
              <span class="smithy-have ${canCraft?'smithy-have-ok':'smithy-have-no'}">tienes ${have}</span>
            </div>
            ${stats ? `<div class="smithy-stats">${stats}</div>` : ''}
            ${(() => { const s = (typeof RUNE_SOCKET_COUNT!=='undefined'?RUNE_SOCKET_COUNT[targetTier]:0)||0; return s ? `<div class="smithy-rune-slots">💎 ${Array(s).fill('◇').join(' ')} ${s} ranura${s>1?'s':''} de runa</div>` : ''; })()}
          </div>
          <button class="smithy-btn ${canCraft?'':'smithy-btn-locked'}"
            onclick="craftWeapon('${def.key}','${targetTier}')" ${canCraft?'':'disabled'}>
            ${canCraft?'⚒️ Forjar':'🔒'}
          </button>
        </div>`;
    });
    return out;
  };

  let rows = weaponOnlyDefs.map(buildRecipeRow).join('');
  const armorRows = armorDefs.map(buildRecipeRow).join('');

  const forgingNow = weapons.filter(w => isForging(w));
  let forgingHtml = '';
  if (forgingNow.length) {
    forgingHtml = `<div class="smithy-forging-queue">
      <div class="smithy-forging-title">🔥 En la Forja (${forgingNow.length})</div>
      ${forgingNow.map(w => {
        const ms   = new Date(w.ready_at) - new Date();
        const h    = Math.floor(ms / 3600000);
        const m    = Math.floor((ms % 3600000) / 60000);
        const tier = WEAPON_TIERS[w.tier] || {};
        return `<div class="smithy-forging-item">
          <span class="smithy-forging-name" style="color:${tier.color || 'var(--text2)'}">${escHtml(w.name)}</span>
          <span class="smithy-forging-timer">${h > 0 ? h + 'h ' : ''}${m}m restantes</span>
        </div>`;
      }).join('')}
    </div>`;
  }

  const bagCount = weapons.filter(w => !w.is_equipped).length;
  el.innerHTML = `
    <div class="smithy-header">
      <p class="smithy-desc">Combina piezas del mismo tipo para forjar versiones más poderosas.<br>
      Los ítems equipados no se pueden usar en recetas.</p>
      ${!bagCount ? `<div class="inv-empty">Sin armas ni armaduras en la mochila.
        <button class="btn btn-ghost" style="padding:3px 10px;font-size:12px" onclick="switchView('shop')">Comprar en Tienda</button>
      </div>` : ''}
    </div>
    ${forgingHtml}
    ${rows ? `<div class="smithy-section-title">⚔️ Armas</div><div class="smithy-recipes">${rows}</div>` : ''}
    ${armorRows ? `<div class="smithy-section-title" style="margin-top:18px">🛡️ Armaduras</div><div class="smithy-recipes">${armorRows}</div>` : ''}
    ${typeof RUNE_DEFS !== 'undefined' ? _renderRuneCrafting() : ''}
    ${typeof _renderSecretSmithy === 'function' ? _renderSecretSmithy() : ''}
  `;
}

function _renderRuneCrafting() {
  const cost = typeof RUNE_FRAG_COST !== 'undefined' ? RUNE_FRAG_COST : 5;
  const rows = Object.entries(RUNE_DEFS).map(([type, def]) => {
    const have     = typeof getInvCount === 'function' ? getInvCount('rune_frag_' + type) : 0;
    const canCraft = have >= cost;
    return `
      <div class="smithy-recipe ${canCraft ? 'smithy-ready' : 'smithy-locked'}">
        <img src="images/${def.fragImg}.webp" class="smithy-img" alt="" style="--wc:${def.color}"
             onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
        <div class="smithy-emoji" style="display:none">${def.icon}</div>
        <div class="smithy-info">
          <div class="smithy-name">${def.name}
            <span class="inv-tier-badge" style="color:${def.color};border-color:${def.color}40;background:${def.color}18">Runa</span>
          </div>
          <div class="smithy-req">
            <span style="color:var(--text2)">${cost}× Fragmento</span>
            <span class="smithy-have ${canCraft ? 'smithy-have-ok' : 'smithy-have-no'}">tienes ${have}</span>
          </div>
          <div class="smithy-stats">${def.desc}</div>
        </div>
        <button class="smithy-btn ${canCraft ? '' : 'smithy-btn-locked'}"
          onclick="craftRune('${type}')" ${canCraft ? '' : 'disabled'}>
          ${canCraft ? '⚒️ Forjar' : '🔒'}
        </button>
      </div>`;
  }).join('');
  return `<div class="smithy-section-title" style="margin-top:18px">💎 Runas (${cost} fragmentos c/u)</div>
          <div class="smithy-recipes">${rows}</div>`;
}
